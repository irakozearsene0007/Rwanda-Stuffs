---
title: "The Ben - Indabo Zanjye (Official Video)"
releaseYear: 2025
duration: "3 min"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "4K"
description: "Produced by KOZZE Directed by Chico Berry Studio: Country Record"
videoUrl: "https://www.youtube.com/embed/qtljBptYzs0"
posterUrl: "https://img.youtube.com/vi/qtljBptYzs0/maxresdefault.jpg"
director: "Chico Berry"
producer: "KOZZE"
mainCast: "The Ben"
supportingCast: ""
metaDescription: "Produced by KOZZE Directed by Chico Berry Studio: Country Record..."
tags: ["the ben","indabo zanjye","rwanda cinema"]
slug: "the-ben-indabo-zanjye-official-video"
date: "2025-12-30T19:29:00.642Z"
---

# The Ben - Indabo Zanjye (Official Video)

Produced by KOZZE
Directed by Chico Berry
Studio: Country Record

## Movie Details

- **Release Year**: 2025
- **Duration**: 3 min
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Director**: Chico Berry
- **Producer**: KOZZE
- **Main Cast**: The Ben

## Watch Now

[Click here to watch "The Ben - Indabo Zanjye (Official Video)"](https://www.youtube.com/embed/qtljBptYzs0)

---

*Uploaded on 12/30/2025*
