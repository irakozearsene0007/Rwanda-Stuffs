---
title: " Bruce Melodie - Pom Pom (Official Video) ft. Diamond Platnumz , Brown"
releaseYear: 2026
duration: "4 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "4K"
description: "Artist Name: Bruce melodie  Featured Artist : Diamond platnumz , Brown Joel   Song Title: POM POM Writers (Full Legal Names): Brice Itahiwacu (Bruce Melodie) ;Naseeb Abdul Juma (Diamond  platnumz) , Agubosim Favour Brown (Brown Joel) Producer(s): C-Tea Beat  Mixing Engineer: C-Tea Beat Mastering Engineer: C-Tea Beat Executive producer: 1:55 AM"
videoUrl: "https://www.youtube.com/embed/hC1lSNjADxc"
posterUrl: "https://img.youtube.com/vi/hC1lSNjADxc/maxresdefault.jpg"
director: ""
producer: "C-Tea Beat"
mainCast: "Bruce Melodie, Diamond Platinumz, Brown Joel"
supportingCast: ""
metaDescription: "Artist Name: Bruce melodie  Featured Artist : Diamond platnumz , Brown Joel   Song Title: POM POM Writers (Full Legal Names): Brice Itahiwacu (Bruce Melodie)..."
tags: []
slug: "bruce-melodie-pom-pom-official-video-ft-diamond-platnumz-brown"
date: "2026-01-03T16:20:52.506Z"
---

#  Bruce Melodie - Pom Pom (Official Video) ft. Diamond Platnumz , Brown

Artist Name: Bruce melodie 
Featured Artist : Diamond platnumz , Brown Joel  
Song Title: POM POM
Writers (Full Legal Names): Brice Itahiwacu (Bruce Melodie) ;Naseeb
Abdul Juma (Diamond  platnumz) , Agubosim Favour Brown (Brown Joel)
Producer(s): C-Tea Beat 
Mixing Engineer: C-Tea Beat
Mastering Engineer: C-Tea Beat
Executive producer: 1:55 AM

## Movie Details

- **Release Year**: 2026
- **Duration**: 4 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Producer**: C-Tea Beat
- **Main Cast**: Bruce Melodie, Diamond Platinumz, Brown Joel

## Watch Now

[Click here to watch " Bruce Melodie - Pom Pom (Official Video) ft. Diamond Platnumz , Brown"](https://www.youtube.com/embed/hC1lSNjADxc)

---

*Uploaded on 1/3/2026*
