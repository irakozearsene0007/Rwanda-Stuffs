---
title: "Kivumbi King - Kabisa (Official Lyric Video)"
releaseYear: 2021
duration: "2:48 minutes"
language: "English"
category: "music"
rating: "G"
quality: "1080p"
description: "“Kabisa” by Kivumbi King blends Afrobeat and Rwandan vibes in a soulful track celebrating love, energy, and authentic emotion."
videoUrl: "https://www.youtube.com/embed/q7xAZFeaVdU?si=89YInKU1z4EVPJQt"
posterUrl: "https://img.youtube.com/vi/q7xAZFeaVdU/maxresdefault.jpg"
director: " Eazy Cuts"
producer: "KennyVbz"
mainCast: "Kivumbi King"
supportingCast: ""
metaDescription: "“Kabisa” by Kivumbi King blends Afrobeat and Rwandan vibes in a soulful track celebrating love, energy, and authentic emotion"
tags: ["Kivumbi king","kabisa","rwandan music","indirmbo nyarwanda","imiziki ya kivumbi king","kivumbi king kabisa"]
slug: "kivumbi-king-kabisa-official-lyric-video"
date: "2025-10-23T14:02:04.289Z"
---

# Kivumbi King - Kabisa (Official Lyric Video)

“Kabisa” by Kivumbi King blends Afrobeat and Rwandan vibes in a soulful track celebrating love, energy, and authentic emotion.

## Movie Details

- **Release Year**: 2021
- **Duration**: 2:48 minutes
- **Language**: English
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Director**:  Eazy Cuts
- **Producer**: KennyVbz
- **Main Cast**: Kivumbi King

## Watch Now

[Click here to watch "Kivumbi King - Kabisa (Official Lyric Video)"](https://www.youtube.com/embed/q7xAZFeaVdU?si=89YInKU1z4EVPJQt)

---

*Uploaded on 10/23/2025*
