---
title: "Kivumbi King - MAMA ft Mike Kayihura (Official Video)"
releaseYear: 2025
duration: "2:56 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "1080p"
description: "Kivumbi King - MAMA ft Mike Kayihura (Official Video)"
videoUrl: "https://odysee.com/@InyarwandaMusics:e/Kivumbi-King---MAMA-ft-Mike-Kayihura-%28Official-Video%29%281080P_HD%29:3"
posterUrl: "https://img.youtube.com/vi/KlK5PfN-k6o/sddefault.jpg"
director: ""
producer: ""
mainCast: "Kivumbi King, Mike Kayihura"
supportingCast: ""
metaDescription: "Kivumbi King - MAMA ft Mike Kayihura (Official Video)..."
tags: []
slug: "kivumbi-mama"
date: "2025-10-30T06:40:21.889Z"
---

# Kivumbi King - MAMA ft Mike Kayihura (Official Video)

Kivumbi King - MAMA ft Mike Kayihura (Official Video)

## Movie Details

- **Release Year**: 2025
- **Duration**: 2:56 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Main Cast**: Kivumbi King, Mike Kayihura

## Watch Now

[Click here to watch "Kivumbi King - MAMA ft Mike Kayihura (Official Video)"](https://odysee.com/@InyarwandaMusics:e/Kivumbi-King---MAMA-ft-Mike-Kayihura-%28Official-Video%29%281080P_HD%29:3)

---

*Uploaded on 10/30/2025*
