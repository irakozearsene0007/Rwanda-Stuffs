export async function onRequestPost(context) {
    const { request, env } = context;
    
    // Add CORS headers
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    // Handle preflight OPTIONS request
    if (request.method === 'OPTIONS') {
        return new Response(null, {
            status: 200,
            headers: corsHeaders
        });
    }
    
    try {
        // Check if request has JSON body
        let movieData;
        try {
            movieData = await request.json();
        } catch (parseError) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Invalid JSON in request body'
            }), {
                status: 400,
                headers: { 
                    'Content-Type': 'application/json',
                    ...corsHeaders 
                }
            });
        }
        
        // Validate required fields
        const requiredFields = ['title', 'contentType', 'videoUrl', 'posterUrl', 'translator'];
        const missingFields = requiredFields.filter(field => !movieData[field]);
        
        if (missingFields.length > 0) {
            return new Response(JSON.stringify({
                success: false,
                message: `Missing required fields: ${missingFields.join(', ')}`
            }), {
                status: 400,
                headers: { 
                    'Content-Type': 'application/json',
                    ...corsHeaders 
                }
            });
        }
        
        // Generate markdown content with ALL fields
        const markdownContent = generateMarkdown(movieData);
        
        // Generate smart filename: [Movie-Name][TV-SERIES or MOVIE][TRANSLATOR-NAME].md
        const fileName = generateSmartFilename(movieData);
        const filePath = `content/translated/${fileName}`;
        
        // Encode content to base64
        const contentBase64 = btoa(unescape(encodeURIComponent(markdownContent)));
        
        // Create GitHub API request
        const githubResponse = await fetch(
            `https://api.github.com/repos/${env.GITHUB_REPO}/contents/${filePath}`,
            {
                method: 'PUT',
                headers: {
                    'Authorization': `token ${env.GITHUB_TOKEN}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'Content-Type': 'application/json',
                    'User-Agent': 'Rwanda-Cinema-App'
                },
                body: JSON.stringify({
                    message: `Add ${movieData.contentType.toLowerCase()}: ${movieData.title}`,
                    content: contentBase64,
                    branch: 'main'
                })
            }
        );
        
        const result = await githubResponse.json();
        
        if (githubResponse.ok) {
            return new Response(JSON.stringify({
                success: true,
                message: 'Movie uploaded successfully',
                filePath: filePath,
                githubUrl: result.content.html_url,
                smartFilename: fileName
            }), {
                status: 200,
                headers: { 
                    'Content-Type': 'application/json',
                    ...corsHeaders 
                }
            });
        } else {
            console.error('GitHub API error:', result);
            throw new Error(result.message || `GitHub API error: ${githubResponse.status}`);
        }
        
    } catch (error) {
        console.error('Function error:', error);
        return new Response(JSON.stringify({
            success: false,
            message: error.message
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                ...corsHeaders 
            }
        });
    }
}

function generateSmartFilename(movieData) {
    // Format: [Movie-Name][TV-SERIES or MOVIE][TRANSLATOR-NAME].md
    const title = movieData.title
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .toUpperCase()
        .substring(0, 40); // Increased limit
    
    const contentType = movieData.contentType.toUpperCase();
    const translator = movieData.translator
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .toUpperCase()
        .substring(0, 20);
    
    return `[${title}][${contentType}][${translator}].md`;
}

function generateMarkdown(movieData) {
    // ALL movie fields in YAML frontmatter
    const frontmatter = {
        // 1. CORE IDENTIFICATION
        title: movieData.title,
        originalTitle: movieData.originalTitle || '',
        contentType: movieData.contentType, // MOVIE or TV-SERIES
        releaseYear: movieData.releaseYear || new Date().getFullYear(),
        releaseDate: movieData.releaseDate || '',
        genres: movieData.genres || ['Drama'],
        mpaaRating: movieData.mpaaRating || 'Not Rated',
        runtime: movieData.runtime || 'Not specified',
        
        // 2. TRANSLATION INFO
        translator: movieData.translator,
        translationDirection: movieData.translationDirection || 'Kinyarwanda-to-English',
        originalLanguage: movieData.originalLanguage || 'Kinyarwanda',
        translatedLanguage: movieData.translatedLanguage || 'English',
        subtitlesAvailable: movieData.subtitlesAvailable || false,
        subtitleLanguages: movieData.subtitleLanguages || [],
        
        // 3. CREATIVE TEAM
        director: movieData.director || '',
        writer: movieData.writer || '',
        producer: movieData.producer || '',
        cinematographer: movieData.cinematographer || '',
        composer: movieData.composer || '',
        editor: movieData.editor || '',
        
        // 4. CAST
        mainCast: movieData.mainCast || [],
        supportingCast: movieData.supportingCast || [],
        voiceCast: movieData.voiceCast || [],
        
        // 5. PRODUCTION DETAILS
        productionCompanies: movieData.productionCompanies || [],
        distributors: movieData.distributors || [],
        countryOfOrigin: movieData.countryOfOrigin || 'Rwanda',
        filmingLocations: movieData.filmingLocations || [],
        budget: movieData.budget || '',
        boxOffice: movieData.boxOffice || '',
        
        // 6. MEDIA URLs
        videoUrl: movieData.videoUrl,
        posterUrl: movieData.posterUrl,
        thumbnailUrl: movieData.thumbnailUrl || movieData.posterUrl,
        trailerUrl: movieData.trailerUrl || '',
        additionalImages: movieData.additionalImages || [],
        backdropUrl: movieData.backdropUrl || '',
        
        // 7. CONTENT DETAILS
        description: movieData.description || '',
        shortDescription: movieData.shortDescription || movieData.description?.substring(0, 150) + '...' || '',
        tagline: movieData.tagline || '',
        plot: movieData.plot || '',
        storyline: movieData.storyline || '',
        
        // 8. TECHNICAL SPECS
        quality: movieData.quality || '1080p',
        audioQuality: movieData.audioQuality || 'Good',
        aspectRatio: movieData.aspectRatio || '16:9',
        color: movieData.color || 'Color',
        soundMix: movieData.soundMix || '',
        
        // 9. AWARDS & RATINGS
        awards: movieData.awards || [],
        nominations: movieData.nominations || [],
        imdbId: movieData.imdbId || '',
        imdbRating: movieData.imdbRating || null,
        imdbVotes: movieData.imdbVotes || 0,
        rottenTomatoesScore: movieData.rottenTomatoesScore || null,
        metacriticScore: movieData.metacriticScore || null,
        
        // 10. CONTENT WARNINGS
        contentWarnings: movieData.contentWarnings || [],
        ageRestriction: movieData.ageRestriction || 0,
        parentalGuidance: movieData.parentalGuidance || '',
        
        // 11. TAGS & KEYWORDS
        keywords: movieData.keywords || [],
        tags: movieData.tags || [],
        themes: movieData.themes || [],
        
        // 12. EPISODE INFO (for TV series)
        seasonNumber: movieData.seasonNumber || 1,
        totalSeasons: movieData.totalSeasons || 1,
        episodeNumber: movieData.episodeNumber || 1,
        episodeCount: movieData.episodeCount || 1,
        episodeTitle: movieData.episodeTitle || '',
        
        // 13. METADATA
        slug: movieData.slug || generateSlug(movieData.title),
        dateAdded: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
        featured: movieData.featured || false,
        trending: movieData.trending || false,
        recommended: movieData.recommended || false,
        views: movieData.views || 0,
        likes: movieData.likes || 0,
        
        // 14. SEO
        metaTitle: movieData.metaTitle || movieData.title,
        metaDescription: movieData.metaDescription || movieData.shortDescription || movieData.description?.substring(0, 157) + '...',
        metaKeywords: movieData.metaKeywords || movieData.keywords || [],
        
        // 15. RELATED CONTENT
        franchise: movieData.franchise || '',
        sequelTo: movieData.sequelTo || '',
        prequelTo: movieData.prequelTo || '',
        relatedMovies: movieData.relatedMovies || [],
        similarContent: movieData.similarContent || []
    };

    // Generate YAML frontmatter
    const yamlContent = `---\n${Object.entries(frontmatter)
        .map(([key, value]) => {
            if (Array.isArray(value)) {
                if (value.length === 0) return `${key}: []`;
                return `${key}:\n${value.map(item => `  - "${escapeYaml(item)}"`).join('\n')}`;
            } else if (typeof value === 'string' && (value.includes('\n') || value.length > 100)) {
                return `${key}: |\n  ${value.replace(/\n/g, '\n  ')}`;
            } else if (typeof value === 'string') {
                return `${key}: "${escapeYaml(value)}"`;
            } else if (typeof value === 'number') {
                return `${key}: ${value}`;
            } else if (typeof value === 'boolean') {
                return `${key}: ${value}`;
            } else if (value === null) {
                return `${key}: null`;
            }
            return `${key}: "${escapeYaml(String(value))}"`;
        })
        .filter(line => !line.includes(': ""') && !line.includes(': []')) // Remove empty fields
        .join('\n')}\n---\n\n`;

    // Generate markdown content
    let markdown = yamlContent;
    
    // Title and tagline
    markdown += `# ${movieData.title}\n\n`;
    
    if (movieData.tagline) {
        markdown += `> *${movieData.tagline}*\n\n`;
    }
    
    // Translation badge
    markdown += `**Translation**: ${movieData.translator} | ${movieData.translationDirection || 'Kinyarwanda to English'}\n\n`;
    
    // Quick info table
    markdown += `## 📋 Quick Info\n\n`;
    markdown += `| Detail | Information |\n`;
    markdown += `|--------|-------------|\n`;
    markdown += `| **Type** | ${movieData.contentType} |\n`;
    markdown += `| **Release Year** | ${movieData.releaseYear || 'N/A'} |\n`;
    if (movieData.releaseDate) markdown += `| **Release Date** | ${movieData.releaseDate} |\n`;
    markdown += `| **Runtime** | ${movieData.runtime || 'N/A'} |\n`;
    markdown += `| **Quality** | ${movieData.quality || '1080p'} |\n`;
    markdown += `| **Rating** | ${movieData.mpaaRating || 'Not Rated'} |\n`;
    markdown += `| **Original Language** | ${movieData.originalLanguage || 'Kinyarwanda'} |\n`;
    markdown += `| **Translated To** | ${movieData.translatedLanguage || 'English'} |\n`;
    markdown += `| **Translator** | ${movieData.translator} |\n`;
    if (movieData.countryOfOrigin) markdown += `| **Country** | ${movieData.countryOfOrigin} |\n`;
    if (movieData.imdbRating) markdown += `| **IMDB Rating** | ${movieData.imdbRating}/10 |\n`;
    
    // For TV series, add episode info
    if (movieData.contentType === 'TV-SERIES') {
        if (movieData.seasonNumber) markdown += `| **Season** | ${movieData.seasonNumber} |\n`;
        if (movieData.episodeNumber) markdown += `| **Episode** | ${movieData.episodeNumber} |\n`;
        if (movieData.episodeTitle) markdown += `| **Episode Title** | ${movieData.episodeTitle} |\n`;
    }
    
    // Synopsis
    markdown += `\n## 📖 Synopsis\n\n`;
    markdown += `${movieData.description}\n\n`;
    
    if (movieData.plot && movieData.plot !== movieData.description) {
        markdown += `## 📜 Detailed Plot\n\n`;
        markdown += `${movieData.plot}\n\n`;
    }
    
    // Cast & Crew section
    const hasCastCrew = movieData.director || movieData.mainCast?.length > 0 || movieData.writer || movieData.producer;
    if (hasCastCrew) {
        markdown += `## 🎬 Cast & Crew\n\n`;
        
        if (movieData.director) {
            markdown += `**Director**: ${movieData.director}\n\n`;
        }
        
        if (movieData.writer) {
            markdown += `**Writer**: ${movieData.writer}\n\n`;
        }
        
        if (movieData.producer) {
            markdown += `**Producer**: ${movieData.producer}\n\n`;
        }
        
        if (movieData.cinematographer) {
            markdown += `**Cinematographer**: ${movieData.cinematographer}\n\n`;
        }
        
        if (movieData.composer) {
            markdown += `**Music Composer**: ${movieData.composer}\n\n`;
        }
        
        if (movieData.mainCast && movieData.mainCast.length > 0) {
            markdown += `**Main Cast**:\n`;
            movieData.mainCast.forEach(actor => {
                markdown += `- ${actor}\n`;
            });
            markdown += `\n`;
        }
        
        if (movieData.supportingCast && movieData.supportingCast.length > 0) {
            markdown += `**Supporting Cast**:\n`;
            movieData.supportingCast.forEach(actor => {
                markdown += `- ${actor}\n`;
            });
            markdown += `\n`;
        }
    }
    
    // Production Details
    const hasProductionDetails = movieData.productionCompanies?.length > 0 || movieData.countryOfOrigin || movieData.filmingLocations?.length > 0;
    if (hasProductionDetails) {
        markdown += `## 🎥 Production Details\n\n`;
        
        if (movieData.productionCompanies && movieData.productionCompanies.length > 0) {
            markdown += `**Production Companies**: ${movieData.productionCompanies.join(', ')}\n\n`;
        }
        
        if (movieData.countryOfOrigin) {
            markdown += `**Country of Origin**: ${movieData.countryOfOrigin}\n\n`;
        }
        
        if (movieData.filmingLocations && movieData.filmingLocations.length > 0) {
            markdown += `**Filming Locations**: ${movieData.filmingLocations.join(', ')}\n\n`;
        }
        
        if (movieData.budget) {
            markdown += `**Budget**: ${movieData.budget}\n\n`;
        }
        
        if (movieData.boxOffice) {
            markdown += `**Box Office**: ${movieData.boxOffice}\n\n`;
        }
    }
    
    // Technical Information
    markdown += `## 🔧 Technical Information\n\n`;
    markdown += `- **Video Quality**: ${movieData.quality || '1080p'}\n`;
    markdown += `- **Audio Quality**: ${movieData.audioQuality || 'Good'}\n`;
    markdown += `- **Subtitles Available**: ${movieData.subtitlesAvailable ? 'Yes' : 'No'}\n`;
    if (movieData.subtitleLanguages && movieData.subtitleLanguages.length > 0) {
        markdown += `- **Subtitle Languages**: ${movieData.subtitleLanguages.join(', ')}\n`;
    }
    if (movieData.aspectRatio) {
        markdown += `- **Aspect Ratio**: ${movieData.aspectRatio}\n`;
    }
    markdown += `- **Translation Quality**: Verified by ${movieData.translator}\n\n`;
    
    // Content Warnings
    if (movieData.contentWarnings && movieData.contentWarnings.length > 0) {
        markdown += `## ⚠️ Content Warnings\n\n`;
        movieData.contentWarnings.forEach(warning => {
            markdown += `- ${warning}\n`;
        });
        markdown += `\n`;
    }
    
    // Awards & Recognition
    if (movieData.awards && movieData.awards.length > 0) {
        markdown += `## 🏆 Awards & Recognition\n\n`;
        movieData.awards.forEach(award => {
            markdown += `- ${award}\n`;
        });
        markdown += `\n`;
    }
    
    // Watch Section
    markdown += `## ▶️ Watch Now\n\n`;
    markdown += `[Click here to watch "${movieData.title}"](${movieData.videoUrl})\n\n`;
    
    if (movieData.trailerUrl) {
        markdown += `[Watch Trailer](${movieData.trailerUrl})\n\n`;
    }
    
    // Genres & Tags
    if (movieData.genres && movieData.genres.length > 0) {
        markdown += `**Genres**: `;
        markdown += movieData.genres.map(genre => `\`${genre}\``).join(' ');
        markdown += `\n\n`;
    }
    
    if (movieData.tags && movieData.tags.length > 0) {
        markdown += `**Tags**: `;
        markdown += movieData.tags.map(tag => `#${tag.replace(/\s+/g, '')}`).join(' ');
        markdown += `\n\n`;
    }
    
    // Footer
    markdown += `---\n\n`;
    markdown += `*Uploaded on ${new Date().toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    })}*\n`;
    markdown += `*Translation provided by: ${movieData.translator}*\n`;
    
    return markdown;
}

function generateSlug(title) {
    return title
        .toLowerCase()
        .trim()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '');
}

function escapeYaml(str) {
    if (!str) return '';
    return str.toString()
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t');
                        }
