---
title: "Juno Kizigenza - Mariza Wanjye ft. Ruti Joel Official Video"
releaseYear: 2025
duration: "4:19 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "4K"
description: "Everyday there’s a new way to love you babe  Mpumuriza umutimaaaa Nyemerera nkwiharire   Umutima ugukunda ntaho wajya  Ntaho wenda kujya  Oohh yeahhh Uuhhh   Nuntumaho sinzatinda  No body pulls me like the way you do Usa n’uwankundakunda  Icyampa chance nkabyumvaho   Hari ukuntu unsiga umubiri  Nkigira impumyi bya maonesho  Nukuri burya mba nshira ii yoooohhh   Girl I go fight for your love Reka tujyane Mariza Ni urukunda ari journey Eehh  Reka tujyane mariza   Girl I go die for your love  Ndeka ngende mariza  Niba urukundo ari journey ndende  Reka tujyane mariza   Ndagukunda mariza wanjye Uri umu Cherie wanjye Nkunda mariza wanjye  Ni wowe wanjye 2X   Nkukunda rurerure  Urukundo ni inzira ndende Ni kure  Sinabasha kuhashyikira ndi umwe  Ngwino tujyane  Igikobwa cya Rumata gusa Ayi weee  Ngwino matako meza abasha inkanda  Ayi weeee  Nkukunda byasaze Mama weeee Jya umpora iruhande maze njye nkurinde  Hari ukuntu unsiga umubiri  Nkigira impumyi bya maonesho  Nukuri burya mba nshira ii yoooohhh   Girl I go fight for your love Reka tujyane Mariza Ni urukunda ari journey Eehh  Reka tujyane mariza   Girl I go die for your love  Ndeka ngende mariza  Niba urukundo ari journey ndende  Reka tujyane mariza   Ndagukunda mariza wanjye Uri umu Cherie wanjye Nkunda mariza wanjye  Ni wowe wanjye 2X    Eeehhhheeee Iyizire bunwa bw’ububogobogo abasore basoma barondereza ngo batazicwa n’inyota weeeee  Eeehheeeeee Ruti mu ngeri baririmba I Nkubito ibimburiza ibigango iyamarere cyane Umuhuuuuuungu ndi amata weeeeeeee"
videoUrl: "https://www.youtube.com/embed/ryEhGKmYR5w"
posterUrl: "https://img.youtube.com/vi/ryEhGKmYR5w/maxresdefault.jpg"
director: "@iam_harris_regis"
producer: " @kompressor"
mainCast: "Juno Kizigenza, Ruti Joel"
supportingCast: "Editor/ Ass Dir :  @samix.rw_ Production Manager : @just_yacky Production Assistant & Gaffer :  @kwizera_eroi Camera Crew : @gihanga, M. Cory, Steve Cast :  @teta_kumba_66 , @murayire.cyane , Ruti Joel, Juno Kizigenza  Makeup Artist : @remim_makeup Costume Designer : @pandemick3 Location Manager : Willy"
metaDescription: "Everyday there’s a new way to love you babe  Mpumuriza umutimaaaa Nyemerera nkwiharire   Umutima ugukunda ntaho wajya  Ntaho wenda kujya  Oohh yeahhh Uuhhh "
tags: ["Juno kizigenza","rwandan musics","rwanda cinema","ruti joel","Maria wanjye song","rwandan songs"]
slug: "juno-kizigenza-mariza-wanjye-ft-ruti-joel"
date: "2025-12-05T19:56:30.928Z"
---

# Juno Kizigenza - Mariza Wanjye ft. Ruti Joel Official Video

Everyday there’s a new way to love you babe 
Mpumuriza umutimaaaa
Nyemerera nkwiharire 

Umutima ugukunda ntaho wajya 
Ntaho wenda kujya 
Oohh yeahhh Uuhhh 

Nuntumaho sinzatinda 
No body pulls me like the way you do
Usa n’uwankundakunda 
Icyampa chance nkabyumvaho 

Hari ukuntu unsiga umubiri 
Nkigira impumyi bya maonesho 
Nukuri burya mba nshira ii yoooohhh 

Girl I go fight for your love
Reka tujyane Mariza
Ni urukunda ari journey Eehh 
Reka tujyane mariza 

Girl I go die for your love 
Ndeka ngende mariza 
Niba urukundo ari journey ndende 
Reka tujyane mariza


Ndagukunda mariza wanjye
Uri umu Cherie wanjye
Nkunda mariza wanjye 
Ni wowe wanjye 2X 

Nkukunda rurerure 
Urukundo ni inzira ndende
Ni kure 
Sinabasha kuhashyikira ndi umwe

Ngwino tujyane 
Igikobwa cya Rumata gusa
Ayi weee 
Ngwino matako meza abasha inkanda

Ayi weeee 
Nkukunda byasaze
Mama weeee
Jya umpora iruhande maze njye nkurinde

Hari ukuntu unsiga umubiri 
Nkigira impumyi bya maonesho 
Nukuri burya mba nshira ii yoooohhh 

Girl I go fight for your love
Reka tujyane Mariza
Ni urukunda ari journey Eehh 
Reka tujyane mariza 

Girl I go die for your love 
Ndeka ngende mariza 
Niba urukundo ari journey ndende 
Reka tujyane mariza


Ndagukunda mariza wanjye
Uri umu Cherie wanjye
Nkunda mariza wanjye 
Ni wowe wanjye 2X 


Eeehhhheeee
Iyizire bunwa bw’ububogobogo abasore basoma barondereza ngo batazicwa n’inyota weeeee

Eeehheeeeee
Ruti mu ngeri baririmba I Nkubito ibimburiza ibigango iyamarere cyane
Umuhuuuuuungu ndi amata weeeeeeee

## Movie Details

- **Release Year**: 2025
- **Duration**: 4:19 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Director**: @iam_harris_regis
- **Producer**:  @kompressor
- **Main Cast**: Juno Kizigenza, Ruti Joel
- **Supporting Cast**: Editor/ Ass Dir :  @samix.rw_ Production Manager : @just_yacky Production Assistant & Gaffer :  @kwizera_eroi Camera Crew : @gihanga, M. Cory, Steve Cast :  @teta_kumba_66 , @murayire.cyane , Ruti Joel, Juno Kizigenza  Makeup Artist : @remim_makeup Costume Designer : @pandemick3 Location Manager : Willy

## Watch Now

[Click here to watch "Juno Kizigenza - Mariza Wanjye ft. Ruti Joel Official Video"](https://www.youtube.com/embed/ryEhGKmYR5w)

---

*Uploaded on 12/5/2025*
