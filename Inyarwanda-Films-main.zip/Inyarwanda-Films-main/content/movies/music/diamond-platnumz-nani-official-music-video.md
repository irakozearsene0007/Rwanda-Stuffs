---
title: "Diamond Platnumz - Nani (Official Music Video)"
releaseYear: 2025
duration: "3 minutes"
language: "Swahili"
category: "music"
rating: "G"
quality: "4K"
description: "In “Nani,” Diamond Platnumz flips the script with a playful love story set in a school — where he stars as a charming teacher who can’t help but fall for the newly appointed teacher. The chemistry is instant, the tension is real, and the visuals bring his flirtatious lyrics to life. In the song, Diamond pours his heart out, saying he has no reason to look elsewhere because she’s his everything. With witty, seductive lines and his signature humor — even admitting how she drives him wild whenever she dresses sexy — Diamond delivers a smooth Bongo Flava anthem about love, temptation, and loyalty. “Nani” is more than a song; it’s a flirt-filled classroom romance told the Diamond Platnumz way — confident, funny, and irresistibly charming."
videoUrl: "https://www.youtube.com/embed/BaSxCDp04WI"
posterUrl: "https://img.youtube.com/vi/BaSxCDp04WI/maxresdefault.jpg"
director: ""
producer: ""
mainCast: "Diamond Platnumz"
supportingCast: ""
metaDescription: "In “Nani,” Diamond Platnumz flips the script with a playful love story set in a school — where he stars as a charming teacher who can’t help but fall for the..."
tags: ["diamond platnumz","tanzanian artist","east african music","tanzania musics","rwanda cinema site"]
slug: "diamond-platnumz-nani-official-music-video"
date: "2025-12-09T10:55:22.501Z"
---

# Diamond Platnumz - Nani (Official Music Video)

In “Nani,” Diamond Platnumz flips the script with a playful love story set in a school — where he stars as a charming teacher who can’t help but fall for the newly appointed teacher. The chemistry is instant, the tension is real, and the visuals bring his flirtatious lyrics to life. In the song, Diamond pours his heart out, saying he has no reason to look elsewhere because she’s his everything. With witty, seductive lines and his signature humor — even admitting how she drives him wild whenever she dresses sexy — Diamond delivers a smooth Bongo Flava anthem about love, temptation, and loyalty. “Nani” is more than a song; it’s a flirt-filled classroom romance told the Diamond Platnumz way — confident, funny, and irresistibly charming.

## Movie Details

- **Release Year**: 2025
- **Duration**: 3 minutes
- **Language**: Swahili
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Main Cast**: Diamond Platnumz

## Watch Now

[Click here to watch "Diamond Platnumz - Nani (Official Music Video)"](https://www.youtube.com/embed/BaSxCDp04WI)

---

*Uploaded on 12/9/2025*
