---
title: "Bruce The 1st - 6AM IN KIGALI Ft Kenny K-Shot"
releaseYear: 2025
duration: "2 minutes 19 seconds"
language: "Kinyarwanda"
category: "music"
rating: "PG"
quality: "1080p"
description: "Produced : Ehlers on the track Mix & Mastering : Pro Zed Directed : B Olly"
videoUrl: "https://www.youtube.com/embed/VQFq-yER8vw"
posterUrl: "https://img.youtube.com/vi/VQFq-yER8vw/maxresdefault.jpg"
director: "Directed : B Olly"
producer: "Ehlers on the track"
mainCast: ""
supportingCast: ""
metaDescription: "Produced : Ehlers on the track Mix & Mastering : Pro Zed Directed : B Olly..."
tags: []
slug: "bruce-the-1st-6am-in-kigali-ft-kenny-k-shot"
date: "2025-12-09T17:29:45.949Z"
---

# Bruce The 1st - 6AM IN KIGALI Ft Kenny K-Shot

Produced : Ehlers on the track
Mix & Mastering : Pro Zed
Directed : B Olly

## Movie Details

- **Release Year**: 2025
- **Duration**: 2 minutes 20 seconds
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: PG
- **Quality**: 1080p

## Cast & Crew

- **Director**: Directed : B Olly
- **Producer**: Ehlers on the track

## Watch Now

[Click here to watch "Bruce The 1st - 6AM IN KIGALI Ft Kenny K-Shot"](https://www.youtube.com/embed/VQFq-yER8vw)

---

*Uploaded on 12/9/2025*
