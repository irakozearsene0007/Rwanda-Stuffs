export async function onRequestGet(context) {
    const { request, env } = context;
    const url = new URL(request.url);
    
    // Get query parameters
    const searchQuery = url.searchParams.get('search') || '';
    const translatorFilter = url.searchParams.get('translator') || '';
    const contentTypeFilter = url.searchParams.get('type') || '';
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = 16; // Videos per page
    
    try {
        // Load all videos
        const allVideos = await loadTranslatedVideos(env);
        
        // Apply filters
        let filteredVideos = allVideos;
        
        if (searchQuery) {
            filteredVideos = searchVideos(allVideos, searchQuery);
        }
        
        if (translatorFilter) {
            filteredVideos = filteredVideos.filter(video => 
                video.translator === translatorFilter.toUpperCase()
            );
        }
        
        if (contentTypeFilter) {
            filteredVideos = filteredVideos.filter(video => 
                video.contentType === contentTypeFilter.toUpperCase()
            );
        }
        
        // Calculate pagination
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedVideos = filteredVideos.slice(startIndex, endIndex);
        
        return new Response(JSON.stringify({
            success: true,
            videos: paginatedVideos,
            page: page,
            limit: limit,
            total: filteredVideos.length,
            hasMore: endIndex < filteredVideos.length
        }), {
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Cache-Control': 'public, max-age=300'
            }
        });
        
    } catch (error) {
        console.error('API error:', error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        });
    }
}

async function loadTranslatedVideos(env) {
    const GITHUB_TOKEN = env.GITHUB_TOKEN;
    const GITHUB_REPO = env.GITHUB_REPO;
    
    try {
        // Get directory listing from content/translated/
        const apiUrl = `https://api.github.com/repos/${GITHUB_REPO}/contents/content/translated`;
        
        const response = await fetch(apiUrl, {
            headers: {
                'Authorization': `token ${GITHUB_TOKEN}`,
                'User-Agent': 'Rwanda-Cinema',
                'Accept': 'application/vnd.github.v3+json'
            }
        });
        
        if (!response.ok) {
            console.error('GitHub API error:', response.status);
            return [];
        }
        
        const files = await response.json();
        const videos = [];
        
        // Process only .md files
        for (const file of files) {
            if (file.name.endsWith('.md') && file.type === 'file') {
                try {
                    // Parse smart filename
                    const parsedInfo = parseSmartFilename(file.name);
                    
                    if (parsedInfo) {
                        const videoData = {
                            filename: file.name,
                            title: parsedInfo.title,
                            contentType: parsedInfo.contentType,
                            translator: parsedInfo.translator,
                            downloadUrl: file.download_url,
                            htmlUrl: file.html_url,
                            sha: file.sha
                        };
                        
                        // Load full content
                        const fullData = await loadVideoDetails(file.download_url);
                        if (fullData) {
                            Object.assign(videoData, fullData);
                        }
                        
                        videos.push(videoData);
                    }
                } catch (error) {
                    console.warn(`Failed to process ${file.name}:`, error.message);
                }
            }
        }
        
        // Sort by date added (newest first)
        return videos.sort((a, b) => new Date(b.dateAdded || 0) - new Date(a.dateAdded || 0));
        
    } catch (error) {
        console.error('Error loading videos:', error);
        return [];
    }
}

function parseSmartFilename(filename) {
    const pattern = /\[([^\]]+)\]\[([^\]]+)\]\[([^\]]+)\]\.md$/;
    const match = filename.match(pattern);
    
    if (match) {
        const [, title, contentType, translator] = match;
        return {
            title: title.replace(/-/g, ' ').trim(),
            contentType: contentType.trim(),
            translator: translator.trim()
        };
    }
    return null;
}

async function loadVideoDetails(downloadUrl) {
    try {
        const response = await fetch(downloadUrl);
        if (!response.ok) return null;
        
        const content = await response.text();
        
        const frontMatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
        if (!frontMatterMatch) return null;
        
        const frontMatter = frontMatterMatch[1];
        const data = {};
        
        frontMatter.split('\n').forEach(line => {
            const match = line.match(/^(\w+):\s*(.+)$/);
            if (match) {
                let [, key, value] = match;
                value = value.replace(/^["'](.*)["']$/, '$1').trim();
                
                if (value.startsWith('[') && value.endsWith(']')) {
                    try {
                        value = JSON.parse(value);
                    } catch (e) {
                        value = [];
                    }
                }
                
                if (key === 'releaseYear' || key === 'views' || key === 'likes') {
                    value = parseInt(value) || 0;
                }
                
                if (value === 'true') value = true;
                if (value === 'false') value = false;
                
                data[key] = value;
            }
        });
        
        return data;
        
    } catch (error) {
        console.warn('Error loading video details:', error);
        return null;
    }
}

function searchVideos(videos, query) {
    const searchTerm = query.toLowerCase().trim();
    if (!searchTerm) return videos;
    
    return videos.filter(video => 
        video.title?.toLowerCase().includes(searchTerm) ||
        video.description?.toLowerCase().includes(searchTerm) ||
        video.translator?.toLowerCase().includes(searchTerm) ||
        (Array.isArray(video.genres) && video.genres.some(genre => 
            genre.toLowerCase().includes(searchTerm)
        )) ||
        (Array.isArray(video.tags) && video.tags.some(tag => 
            tag.toLowerCase().includes(searchTerm)
        ))
    );
    }
