---
title: "Kivumbi King - Salute (Official Video)"
releaseYear: 2022
duration: "2:55 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "1080p"
description: "Kivumbi King - Salute (Official Video) Release Date: June 24, 2022 Artist: Kivumbi King Location: Rwanda"
videoUrl: "https://odysee.com/Kivumbi-King---Salute-%28Official-Video%29%281080P_HD%29:cc1540417dff1ebfcafe31a7ebfaf2786926cc00"
posterUrl: "https://img.youtube.com/vi/IyZiiL22s3k/maxresdefault.jpg"
director: ""
producer: ""
mainCast: ""
supportingCast: ""
metaDescription: "“Salute” ya Kivumbi King, indirimbo ya 2022 yuje Afrobeat n’ubutumwa bukomeye, igaragaza impano nyarwanda n’ishema ry’u Rwanda."
tags: []
slug: "kivumbi-king-salute"
date: "2025-10-23T10:26:45.020Z"
---

# Kivumbi King - Salute (Official Video)

Kivumbi King - Salute (Official Video)
Release Date: June 24, 2022
Artist: Kivumbi King
Location: Rwanda

## Movie Details

- **Release Year**: 2022
- **Duration**: 2:55 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

Not specified

## Watch Now

[Click here to watch "Kivumbi King - Salute (Official Video)"](https://odysee.com/Kivumbi-King---Salute-%28Official-Video%29%281080P_HD%29:cc1540417dff1ebfcafe31a7ebfaf2786926cc00)

---

*Uploaded on 10/23/2025*
