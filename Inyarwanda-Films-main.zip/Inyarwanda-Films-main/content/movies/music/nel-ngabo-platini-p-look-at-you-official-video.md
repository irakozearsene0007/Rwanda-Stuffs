---
title: "Nel Ngabo & Platini P - Look at you (Official Video)"
releaseYear: 2025
duration: "2:58 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "4K"
description: "Nel Ngabo na Platini P - Look at You ni indirimbo y'urukundo ifite amashusho atangaje. Reba videwo y'iyi ndirimbo y'ubuhanga kandi wumve umudiho!"
videoUrl: "https://www.youtube.com/embed/lBnokNKI38I?si=gyIu21iLuMTpPGfu"
posterUrl: "https://img.youtube.com/vi/lBnokNKI38I/maxresdefault.jpg"
director: "Meddy Saleh "
producer: "I.K. Clement"
mainCast: "Nel Ngabo, Platini P, Mamba"
supportingCast: ""
metaDescription: "Nel Ngabo na Platini P - Look at You ni indirimbo y'urukundo ifite amashusho atangaje. Reba videwo y'iyi ndirimbo y'ubuhanga kandi wumve umudiho!..."
tags: ["Nel NGabo","Platini P","Look at you","rwandan musics","new rwandan movies"]
slug: "nel-ngabo-platini-p-look-at-you-official-video"
date: "2025-11-03T12:36:17.024Z"
---

# Nel Ngabo & Platini P - Look at you (Official Video)

Nel Ngabo na Platini P - "Look at You" ni indirimbo y'urukundo ifite amashusho atangaje. Reba videwo y'iyi ndirimbo y'ubuhanga kandi wumve umudiho!

## Movie Details

- **Release Year**: 2025
- **Duration**: 2:58 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Director**: Meddy Saleh 
- **Producer**: I.K. Clement
- **Main Cast**: Nel Ngabo, Platini P, Mamba

## Watch Now

[Click here to watch "Nel Ngabo & Platini P - Look at you (Official Video)"](https://www.youtube.com/embed/lBnokNKI38I?si=gyIu21iLuMTpPGfu)

---

*Uploaded on 11/3/2025*
