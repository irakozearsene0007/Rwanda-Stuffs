---
title: "Kivumbi King - Macarena (Official Video)"
releaseYear: 2025
duration: "3 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "1080p"
description: "Kivumbi King Macarena Lyrics  Sinakubeshya ngo nd’inama Ndi badman Aba x nkamaganatatu tranna kill a man Hold on pretty one , pretty one  Nkukeneye amasaha atari safer  King Salom a thousand pretty gyal Slow wine pon di dance She don’t fall for the rich and famous  She loves  a ghetto aura farmers  “I,ve never seen any girl like you Slim waist her ass fat too Mon coeur my cheri my boo I’d drop Alla dem for you. “ *2  “Hey Macarena Macarena Macarena  Squeeze mi a inner inner inner Nyenya akabina bina bina bina wakati Ntubicishe amayira. “ *2   Hey macarena waje unyereka indi nzira Umanukana mukibira ngwamo ndinka Che Guevara  Hey macarena useka neza nka Makeda Ninkukira kukabina tell me does it even matter  Caught muri danger nkahubuka Iyi nkubonye ngo uraje ndakotora Nkushaka uruwanjye never relax If you come to my address would you return*2  “I,ve never seen any girl like you Slim waist her ass fat too Mon coeur my cheri my boo I’d drop Alla dem for you. “ *2  “Hey Macarena Macarena Macarena  Squeeze mi a inner inner inner Nyenya akabina bina bina bina Ntubicishe amayira. “ *2"
videoUrl: "https://www.youtube.com/embed/cGnpOIRNDsM"
posterUrl: "https://img.youtube.com/vi/cGnpOIRNDsM/maxresdefault.jpg"
director: "Olaf Datus"
producer: ""
mainCast: "Kivumbi King"
supportingCast: ""
metaDescription: "Reba amashusho y’indirimbo ‘Macarena’ ya Kivumbi King. Iyi ndirimbo izakurura umunezero n’imbyino zigezweho mu buryo bwihariye...."
tags: ["Kivumbi KIng","Macarena kivumbi","rwandan musics","rwanda songs","new rwandan musics","indirimbo nyarwanda"]
slug: "kivumbi-king-macarena-official-video"
date: "2025-12-07T17:28:05.785Z"
---

# Kivumbi King - Macarena (Official Video)

Kivumbi King Macarena Lyrics

Sinakubeshya ngo nd’inama
Ndi badman
Aba x nkamaganatatu tranna kill a man
Hold on pretty one , pretty one 
Nkukeneye amasaha atari safer

King Salom a thousand pretty gyal
Slow wine pon di dance
She don’t fall for the rich and famous 
She loves  a ghetto aura farmers

“I,ve never seen any girl like you
Slim waist her ass fat too
Mon coeur my cheri my boo
I’d drop Alla dem for you. “ *2

“Hey Macarena Macarena Macarena 
Squeeze mi a inner inner inner
Nyenya akabina bina bina bina wakati
Ntubicishe amayira. “ *2 

Hey macarena waje unyereka indi nzira
Umanukana mukibira ngwamo ndinka Che Guevara

Hey macarena useka neza nka Makeda
Ninkukira kukabina tell me does it even matter

Caught muri danger nkahubuka
Iyi nkubonye ngo uraje ndakotora
Nkushaka uruwanjye never relax
If you come to my address would you return*2

“I,ve never seen any girl like you
Slim waist her ass fat too
Mon coeur my cheri my boo
I’d drop Alla dem for you. “ *2

“Hey Macarena Macarena Macarena 
Squeeze mi a inner inner inner
Nyenya akabina bina bina bina
Ntubicishe amayira. “ *2

## Movie Details

- **Release Year**: 2025
- **Duration**: 3 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Director**: Olaf Datus
- **Main Cast**: Kivumbi King

## Watch Now

[Click here to watch "Kivumbi King - Macarena (Official Video)"](https://www.youtube.com/embed/cGnpOIRNDsM)

---

*Uploaded on 12/7/2025*
