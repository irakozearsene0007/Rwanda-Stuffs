---
title: "Kenny K Shot & Kivumbi King Izina official Video"
releaseYear: 2025
duration: "4 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "1080p"
description: "Kenny K Shot & Kivumbi King Izina official Video"
videoUrl: "https://www.youtube.com/embed/DkaflVXgxAw"
posterUrl: "https://img.youtube.com/vi/DkaflVXgxAw/maxresdefault.jpg"
director: ""
producer: ""
mainCast: "Kenny K Shot, Kivumbi King"
supportingCast: ""
metaDescription: "Kenny K Shot & Kivumbi King Izina official Video..."
tags: []
slug: "kenny-k-shot-kivumbi-king-izina-official-video"
date: "2025-11-15T15:26:38.691Z"
---

# Kenny K Shot & Kivumbi King Izina official Video

Kenny K Shot & Kivumbi King Izina official Video

## Movie Details

- **Release Year**: 2025
- **Duration**: 4 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Main Cast**: Kenny K Shot, Kivumbi King

## Watch Now

[Click here to watch "Kenny K Shot & Kivumbi King Izina official Video"](https://www.youtube.com/embed/DkaflVXgxAw)

---

*Uploaded on 11/15/2025*
