---
title: "Dany Nanone feat Chriss Eazy - SAMPE (Official Video)"
releaseYear: 2025
duration: "3 min 40 sec"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "4K"
description: "Presenting to you The official video of SAMPE by Dany Nanone feat ‪@chrisseazy_‬   Video Producer : Fayzo Pro Audio producer : Element Eleeeh DOP : Tallboy Editor : Sanib Colorist : Director C Makeup : The Gazelle Stylist : Young C Set Organizer : Njuga  Choreographer : Aspino Dancers: African Mirror in a Partnership with: GITI iNC"
videoUrl: "https://www.youtube.com/embed/XNKG3ODE_J8"
posterUrl: "https://img.youtube.com/vi/XNKG3ODE_J8/maxresdefault.jpg"
director: ""
producer: "Element Eleeeeh"
mainCast: "Chris Eazy and Danny Nanone"
supportingCast: ""
metaDescription: "Indirimbo SAMPE ya Dany Nanone feat Chriss Eazy igaruka ku rukundo n’amarangamutima akomeye, amajwi meza n’amashusho yemewe yo mu 2025."
tags: ["danny nanone","chris eazy","rwandan music","inyarwanda cinema","kigali","Dany Nanone feat Chriss Eazy - SAMPE (Official Video)","rwanda","imiziki nyarwanda"]
slug: "dany-nanone-feat-chriss-eazy-sampe-official-video"
date: "2025-12-14T09:47:38.405Z"
---

# Dany Nanone feat Chriss Eazy - SAMPE (Official Video)

Presenting to you The official video of SAMPE by Dany Nanone feat ‪@chrisseazy_‬ 

Video Producer : Fayzo Pro
Audio producer : Element Eleeeh
DOP : Tallboy
Editor : Sanib
Colorist : Director C
Makeup : The Gazelle
Stylist : Young C
Set Organizer : Njuga 
Choreographer : Aspino
Dancers: African Mirror
in a Partnership with: GITI iNC

## Movie Details

- **Release Year**: 2025
- **Duration**: 3 min 40 sec
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Producer**: Element Eleeeeh
- **Main Cast**: Chris Eazy and Danny Nanone

## Watch Now

[Click here to watch "Dany Nanone feat Chriss Eazy - SAMPE (Official Video)"](https://www.youtube.com/embed/XNKG3ODE_J8)

---

*Uploaded on 12/14/2025*
