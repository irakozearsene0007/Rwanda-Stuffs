---
title: "Badal | Bobby Deol, Rani Mukerji | 90's Superhit Movie"
releaseYear: 2000
duration: "2h 46m"
language: "English"
category: "action"
rating: "G"
quality: "1080p"
description: "Badal is a Hindi film, released in the year 2000. The story revolves around a boy who witnessed the death of his family members by a cruel police officer. On growing up, the boy decided to take revenge from the police officer for his loss. The film was directed by Raj Kanwar.  Movie Credits Badal (2000)  Film cast: Bobby Deol, Rani Mukherjee, Mayuri Kango, Johny Lever, Aashish Vidyarthi, Neena Kulkarni, Upasna Singh, Ashutosh Rana, Amrish Puri, Suman Ranganathan, Mink, Shahbaaz Khan, Dina Pathak, Alok Nath, Harish Patel, Mushtaq Khan, Vishwajeet Pradhan, Kulbhushan Kharbanda, Salim Ghouse, Dinesh Anand, Mandira Bedi, Akash Khurana, Sana Saeed Singer: Anmol, Anu Malik, Anuradha Paudwal, Dominique Cerejo, Jaspinder Narula, Kavita Krishnamurthy, Sapna Awasthi, Sonu Nigam, Sukhwinder Singh, Udit Narayan Lyricist: Sameer Music Director: Anu Malik Film Director: Raj Kanwar  Film Producer: Habib Tanvir, Salim, Salim Akhtar"
videoUrl: "https://www.youtube.com/embed/gptw_56x71g"
posterUrl: "https://img.youtube.com/vi/3HYOyrMSt0Y/maxresdefault.jpg"
director: ""
producer: ""
mainCast: "Bobby Deol, Rani Mukherjee, Mayuri Kango, Johny Lever, Aashish Vidyarthi, Neena Kulkarni, Upasna Singh, Ashutosh Rana, Amrish Puri, Suman Ranganathan, Mink, Shahbaaz Khan, Dina Pathak, Alok Nath, Harish Patel, Mushtaq Khan, Vishwajeet Pradhan, Kulbhushan Kharbanda, Salim Ghouse, Dinesh Anand, Mandira Bedi, Akash Khurana, Sana Saeed"
supportingCast: "Anmol, Anu Malik, Anuradha Paudwal, Dominique Cerejo, Jaspinder Narula, Kavita Krishnamurthy, Sapna Awasthi, Sonu Nigam, Sukhwinder Singh, Udit Narayan"
metaDescription: "Badal is a Hindi film, released in the year 2000. The story revolves around a boy who witnessed the death of his family members by a cruel police officer. On..."
tags: []
slug: "badal-bobby-deol-rani-mukerji-90s-superhit-movie"
date: "2025-12-31T20:23:28.033Z"
---

# Badal | Bobby Deol, Rani Mukerji | 90's Superhit Movie

Badal is a Hindi film, released in the year 2000. The story revolves around a boy who witnessed the death of his family members by a cruel police officer. On growing up, the boy decided to take revenge from the police officer for his loss. The film was directed by Raj Kanwar.

Movie Credits
Badal (2000) 
Film cast: Bobby Deol, Rani Mukherjee, Mayuri Kango, Johny Lever, Aashish Vidyarthi, Neena Kulkarni, Upasna Singh, Ashutosh Rana, Amrish Puri, Suman Ranganathan, Mink, Shahbaaz Khan, Dina Pathak, Alok Nath, Harish Patel, Mushtaq Khan, Vishwajeet Pradhan, Kulbhushan Kharbanda, Salim Ghouse, Dinesh Anand, Mandira Bedi, Akash Khurana, Sana Saeed
Singer: Anmol, Anu Malik, Anuradha Paudwal, Dominique Cerejo, Jaspinder Narula, Kavita Krishnamurthy, Sapna Awasthi, Sonu Nigam, Sukhwinder Singh, Udit Narayan
Lyricist: Sameer
Music Director: Anu Malik
Film Director: Raj Kanwar 
Film Producer: Habib Tanvir, Salim, Salim Akhtar

## Movie Details

- **Release Year**: 2000
- **Duration**: 2h 46m
- **Language**: English
- **Category**: action
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Main Cast**: Bobby Deol, Rani Mukherjee, Mayuri Kango, Johny Lever, Aashish Vidyarthi, Neena Kulkarni, Upasna Singh, Ashutosh Rana, Amrish Puri, Suman Ranganathan, Mink, Shahbaaz Khan, Dina Pathak, Alok Nath, Harish Patel, Mushtaq Khan, Vishwajeet Pradhan, Kulbhushan Kharbanda, Salim Ghouse, Dinesh Anand, Mandira Bedi, Akash Khurana, Sana Saeed
- **Supporting Cast**: Anmol, Anu Malik, Anuradha Paudwal, Dominique Cerejo, Jaspinder Narula, Kavita Krishnamurthy, Sapna Awasthi, Sonu Nigam, Sukhwinder Singh, Udit Narayan

## Watch Now

[Click here to watch "Badal | Bobby Deol, Rani Mukerji | 90's Superhit Movie"](https://www.youtube.com/embed/gptw_56x71g)

---

*Uploaded on 12/31/2025*
