---
title: "Element Eleéeh - MAASO (Official Music Video)"
releaseYear: 2025
duration: "4:28 minutes"
language: "Kinyarwanda"
category: "music"
rating: "G"
quality: "1080p"
description: "ELEMENT EleéeH presents the official music video for \"MAASO\"."
videoUrl: "https://www.youtube.com/embed/s1uZO-SHfts"
posterUrl: "https://img.youtube.com/vi/s1uZO-SHfts/maxresdefault.jpg"
director: " KAiRO"
producer: "Element Eleéeh"
mainCast: "Element Eleéeh"
supportingCast: "Executive Producers: Eleéesphere Acoustic Guitar: Jules Hirwa Bass Guitar: Arnaud Gasige Mixing: Glenn Mastering Engeneer: Lay Co-Mastering: Bob Pro Production Team: KAiRO Films Colorist: Ben Aitar Editor: GAD Graphics: Uniquo Costumes: Rockwood"
metaDescription: "ELEMENT EleéeH presents the official music video for \"MAASO\"...."
tags: []
slug: "element-eleeh-maaso-official-music-video"
date: "2025-11-11T14:58:00.600Z"
---

# Element Eleéeh - MAASO (Official Music Video)

ELEMENT EleéeH presents the official music video for "MAASO".

## Movie Details

- **Release Year**: 2025
- **Duration**: 4:28 minutes
- **Language**: Kinyarwanda
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Director**:  KAiRO
- **Producer**: Element Eleéeh
- **Main Cast**: Element Eleéeh
- **Supporting Cast**: Executive Producers: Eleéesphere Acoustic Guitar: Jules Hirwa Bass Guitar: Arnaud Gasige Mixing: Glenn Mastering Engeneer: Lay Co-Mastering: Bob Pro Production Team: KAiRO Films Colorist: Ben Aitar Editor: GAD Graphics: Uniquo Costumes: Rockwood

## Watch Now

[Click here to watch "Element Eleéeh - MAASO (Official Music Video)"](https://www.youtube.com/embed/s1uZO-SHfts)

---

*Uploaded on 11/11/2025*
