---
title: "ArrDee x Mazza L20 - Trouble (Official Music Video)"
releaseYear: 2025
duration: "3 minutes"
language: "English"
category: "music"
rating: "G"
quality: "1080p"
description: "What’s Happening I’m Back In Trouble The Girls I Like Are Mad Bad And They Ain’t Acting Subtle Damn  Tryna It Outs A Struggle Gyatt Love An Elastic Model Body Plastic Bottle You Know The Motto Don’t Get Caught N Make Sure They Don’t Follow  What’s Happening  I’m Back In Trouble They’re putting together the puzzle  they got no clue got left in a muddle  Ay this bulldogs got no muzzle  you might get bitten just trying to tussle i come with a w** no muscle  you know the motto  don’t get caught and make sure they don’t follow   I’m back in trouble  AJ & Klitchko but f*** it is what it is though  with g lock put it in switch mode  not a whip but i put it in limp mode  i used to bang my s**** like a nympho  why do the rats keep giving in info i was banged up just looking at windows miss how the s*** rings off like a ringtone l cat b didn’t send me to lindo  kicked in heads till I busted me shinbone full house on the block not bingo  remember when we used to get chased by blingos  coulda died when we smoked up jimbos  i was in his back yard like kimbo aim for the what  have him doing the limbo  getting in trouble they’re loving the lingo    The lifestyle mazza  I party like gazza I want her i have her I ain’t gotta shoot my shoot like wazza only on blocks when my girls on passa only hit shots if it’s outta the bottle she get super soaked make puddles i get stupid dough on a doddle chicks move loose cuz we live full throttle I’m selfish 10 girl help it tell em no phones or selfies just got her nails did toes matching and the freak wants them where my mouth is will i get caught i doubt it when you this lit fit bitches allow sh** arrdee don’t run out of girls tell mazza i need him to sort me scouse chick   What’s Happening  I’m Back In Trouble They’re putting together the puzzle  they got no clue got left in a muddle  Ay this bulldogs got no muzzle  you might get bitten just trying to tussle i come with a w** no muscle  you know the motto  don’t get caught and make sure they don’t follow   What’s Happening I’m Back In Trouble The Girls I Like Are Mad Bad And They Ain’t Acting Subtle Damn  Tryna It Outs A Struggle Gyatt Love An Elastic Model Body Plastic Bottle You Know The Motto Don’t Get Caught N Make Sure They Don’t Follow  coulda died when he smoked up medways  ride on rats don’t ride no segways  heard suttin got shot round them ways chest shot what you know about chest pain  go hard bro even on rest days  even on sundays  even on wednesday  your a yes man you just have yes days go gym but you’re missing out leg day  i dont hear them couldn’t comprènde wouldn’t get near my worst on their best day no fear tell her bring in her bestie 2 chicks here got their stripes sensie stripes like tiger cellulite long lengs  spider  caught in a web of mine don’t tell lies so my girls don’t get in fights  cuz they chose this life let’s get it right  What’s Happening I’m Back In Trouble The Girls I Like Are Mad Bad And They Ain’t Acting Subtle Damn  Tryna It Outs A Struggle Gyatt Love An Elastic Model Body Plastic Bottle You Know The Motto Don’t Get Caught N Make Sure They Don’t Follow  What’s Happening  I’m Back In Trouble They’re putting together the puzzle  they got no clue got left in a muddle  Ay this bulldogs got no muzzle  you might get bitten just trying to tussle i come with a w** no muscle  you know the motto  don’t get caught and make sure they don’t follow"
videoUrl: "https://www.youtube.com/embed/ngF7mVT0ghU"
posterUrl: "https://img.youtube.com/vi/ngF7mVT0ghU/maxresdefault.jpg"
director: ""
producer: ""
mainCast: "Ardee, Mazza L20"
supportingCast: ""
metaDescription: "What’s Happening I’m Back In Trouble The Girls I Like Are Mad Bad And They Ain’t Acting Subtle Damn  Tryna It Outs A Struggle Gyatt Love An Elastic Model Bod..."
tags: ["Ardee","ArrDee x Mazza L20 - Trouble (Official Music Video)"]
slug: "arrdee-x-mazza-l20-trouble-official-music-video"
date: "2025-12-09T11:03:03.862Z"
---

# ArrDee x Mazza L20 - Trouble (Official Music Video)

What’s Happening
I’m Back In Trouble
The Girls I Like Are Mad
Bad
And They Ain’t Acting Subtle
Damn 
Tryna It Outs A Struggle
Gyatt
Love An Elastic Model
Body
Plastic Bottle
You Know The Motto
Don’t Get Caught
N Make Sure They Don’t Follow

What’s Happening 
I’m Back In Trouble
They’re putting together the puzzle 
they got no clue got left in a muddle 
Ay this bulldogs got no muzzle 
you might get bitten just trying to tussle
i come with a w** no muscle 
you know the motto 
don’t get caught and make sure they don’t follow 

I’m back in trouble 
AJ & Klitchko
but f*** it is what it is though 
with g lock put it in switch mode 
not a whip but i put it in limp mode 
i used to bang my s**** like a nympho 
why do the rats keep giving in info
i was banged up just looking at windows
miss how the s*** rings off like a ringtone l
cat b didn’t send me to lindo 
kicked in heads till I busted me shinbone
full house on the block not bingo 
remember when we used to get chased by blingos 
coulda died when we smoked up jimbos 
i was in his back yard like kimbo
aim for the what 
have him doing the limbo 
getting in trouble they’re loving the lingo 


The lifestyle mazza 
I party like gazza
I want her i have her
I ain’t gotta shoot my shoot like wazza
only on blocks when my girls on passa
only hit shots if it’s outta the bottle
she get super soaked make puddles
i get stupid dough on a doddle
chicks move loose cuz we live full throttle
I’m selfish
10 girl help it
tell em no phones or selfies
just got her nails did
toes matching
and the freak wants them where my mouth is
will i get caught i doubt it
when you this lit fit bitches allow sh**
arrdee don’t run out of girls
tell mazza i need him to sort me scouse chick 

What’s Happening 
I’m Back In Trouble
They’re putting together the puzzle 
they got no clue got left in a muddle 
Ay this bulldogs got no muzzle 
you might get bitten just trying to tussle
i come with a w** no muscle 
you know the motto 
don’t get caught and make sure they don’t follow 

What’s Happening
I’m Back In Trouble
The Girls I Like Are Mad
Bad
And They Ain’t Acting Subtle
Damn 
Tryna It Outs A Struggle
Gyatt
Love An Elastic Model
Body
Plastic Bottle
You Know The Motto
Don’t Get Caught
N Make Sure They Don’t Follow

coulda died when he smoked up medways 
ride on rats don’t ride no segways 
heard suttin got shot round them ways
chest shot what you know about chest pain 
go hard bro
even on rest days 
even on sundays 
even on wednesday 
your a yes man you just have yes days
go gym but you’re missing out leg day

i dont hear them couldn’t comprènde
wouldn’t get near my worst on their best day
no fear tell her bring in her bestie
2 chicks here got their stripes sensie
stripes like tiger
cellulite
long lengs 
spider 
caught in a web of mine
don’t tell lies so my girls don’t get in fights 
cuz they chose this life let’s get it right

What’s Happening
I’m Back In Trouble
The Girls I Like Are Mad
Bad
And They Ain’t Acting Subtle
Damn 
Tryna It Outs A Struggle
Gyatt
Love An Elastic Model
Body
Plastic Bottle
You Know The Motto
Don’t Get Caught
N Make Sure They Don’t Follow

What’s Happening 
I’m Back In Trouble
They’re putting together the puzzle 
they got no clue got left in a muddle 
Ay this bulldogs got no muzzle 
you might get bitten just trying to tussle
i come with a w** no muscle 
you know the motto 
don’t get caught and make sure they don’t follow

## Movie Details

- **Release Year**: 2025
- **Duration**: 3 minutes
- **Language**: English
- **Category**: music
- **Content Rating**: G
- **Quality**: 1080p

## Cast & Crew

- **Main Cast**: Ardee, Mazza L20

## Watch Now

[Click here to watch "ArrDee x Mazza L20 - Trouble (Official Music Video)"](https://www.youtube.com/embed/ngF7mVT0ghU)

---

*Uploaded on 12/9/2025*
