---
title: "USiSiTE - Vestine & Dorcas ( Official Video 2025)"
releaseYear: 2025
duration: "9:16 minutes"
language: "Swahili"
category: "music"
rating: "G"
quality: "4K"
description: " MIE Music Presents .  USISITE  🎵 Director: Chriss Eazy Music: Popieeh  Lyrics ✍️: Niyo Bosco and M.Irene Artenate Director: Sinta Filmz Dop:Figma 🎸 Guitars: Arsene & Gasige Arnoud  Set Designer: Honore Wardu Set Manager :Hussein Traole COLOR: Uniquo Dop: Figma Set Designer: Honore Wardu Costumer designer : Incabure. Location : BUHANGA ECO LODGE - MUSANZE                    Vancouver -Canada EXECUTIVE PRODUCER: MIE Music   LYRICS : Inuka Juuu kuriko makovu yako  Inuka kwenye majivuu,  kwa sababu Huyu ni mdaa wako  Mungu atatimiza ahadi zote zako  utakumbatia mabadiriko mapya ,   Minyororo inakatika, kuta zinaanguka When Jesus says Yes  Alikuwuumba  kwa udongo ,  Akamwanga Damu yake kwa ajili yako Yeye hasemi uongo , ni mwamifu every time x2  Alifungua njia kati ya bahari  Na mapito kati ya maji yenye nguvu nyingi Msiyakumbuke  mambo ya zamani. Aliitenda jambo jipyaaa Tazama  Leo na Kesho anakujaza furaha  Anaweka Maneno katika vitendo Jarah  Chochote wanachopanga  it doesn’t really Matter USISITE Mwaminiye kwanza Baraka zitafuuata USISITE Ana kujua , Anakukumbuka   USISITE Anakutunza  ,Anakufahamu USISITE  Kama vile mbingu zilivyo juu kuliko,Dunia hivyo ndivyo asiyeringanishwa na mwanadamu  Mungu ni Bwana wa yasiyowezekana Kesi yako sio mkuu Mgongo wake ni mwema na uko daima kukubeba , Nyosha mikono yako, naye atakushika Yeye ni mzazi mwenye rehema ,  Mkimbilie atakupokeya ,  Ni yeye tu anayeweza kuponya majeraha yako  Yeye kamwe hashindwi  Tuna ushuhuda mwingi ,  Our Father is the King . Never Be , Never Be Afraid  Alifungua njia kati ya bahari  Na mapito kati ya maji yenye nguvu nyingi Msiyakumbuke  mambo ya zamani. Aliitenda jambo jipyaaa Tazama  Leo na Kesho anakujaza furaha  Anaweka Maneno katika vitendo Jarah  Chochote wanachopanga  it doesn’t really Matter USISITE Mwaminiye kwanza Baraka zitafuuata USISITE Ana kujua , Anakukumbuka   USISITE Anakutunza  ,Anakufahamu USISITE  Mipango yake kwako ni njema hawezi kukuacha Yatima he is always there for you USISISITE X 4  Aliitenda jambo jipyaaa Tazama  Leo na Kesho anakujaza furaha  Anaweka Maneno katika vitendo Jarah  Chochote wanachopanga  it doesn’t really Matter USISITE Mwaminiye kwanza Baraka zitafuuata USISITE Ana kujua , Anakukumbuka   USISITE Anakutunza  ,Anakufahamu USISITE  MIE Music \"Jesus is our Shepherd'"
videoUrl: "https://www.youtube.com/embed/40-sh4v4K8M"
posterUrl: "https://img.youtube.com/vi/40-sh4v4K8M/maxresdefault.jpg"
director: "Chriss Eazy"
producer: "Popieeh"
mainCast: "Vestine, Dorcas"
supportingCast: ""
metaDescription: "USiSiTE ya Vestine & Dorcas (Official Video 2025) irimo ubutumwa bukiza, amajwi meza n’indirimbo ishimisha. Reba iyi ndirimbo nshya ihumure ritanga ibyishimo."
tags: ["Vestine","dorcas","gospel rwanda","vestine na dorcas","USiSiTE - Vestine & Dorcas ( Official Video 2025)","rwanda gospel","israel mbonyi","youtube rwanda","youtube","rwanda cinema site","inyarwanda musics","imiziki nyarwanda","usisite","mbonyi gospel"]
slug: "usisite-vestine-dorcas-official-video-2025"
date: "2025-12-12T07:09:00.982Z"
---

# USiSiTE - Vestine & Dorcas ( Official Video 2025)


MIE Music Presents . 
USISITE  🎵
Director: Chriss Eazy
Music: Popieeh 
Lyrics ✍️: Niyo Bosco and M.Irene
Artenate Director: Sinta Filmz
Dop:Figma
🎸 Guitars: Arsene & Gasige Arnoud 
Set Designer: Honore Wardu
Set Manager :Hussein Traole
COLOR: Uniquo
Dop: Figma
Set Designer: Honore Wardu
Costumer designer : Incabure.
Location : BUHANGA ECO LODGE - MUSANZE 
                  Vancouver -Canada
EXECUTIVE PRODUCER: MIE Music


LYRICS :
Inuka Juuu kuriko makovu yako 
Inuka kwenye majivuu, 
kwa sababu Huyu ni mdaa wako 
Mungu atatimiza ahadi zote zako 
utakumbatia mabadiriko mapya , 

Minyororo inakatika, kuta zinaanguka
When Jesus says Yes 
Alikuwuumba  kwa udongo , 
Akamwanga Damu yake kwa ajili yako
Yeye hasemi uongo , ni mwamifu every time x2

Alifungua njia kati ya bahari 
Na mapito kati ya maji yenye nguvu nyingi
Msiyakumbuke  mambo ya zamani.
Aliitenda jambo jipyaaa Tazama

Leo na Kesho anakujaza furaha 
Anaweka Maneno katika vitendo Jarah 
Chochote wanachopanga 
it doesn’t really Matter USISITE
Mwaminiye kwanza Baraka zitafuuata USISITE
Ana kujua , Anakukumbuka 
 USISITE
Anakutunza  ,Anakufahamu
USISITE

Kama vile mbingu zilivyo juu kuliko,Dunia
hivyo ndivyo asiyeringanishwa na mwanadamu 
Mungu ni Bwana wa yasiyowezekana
Kesi yako sio mkuu
Mgongo wake ni mwema na uko daima kukubeba ,
Nyosha mikono yako, naye atakushika
Yeye ni mzazi mwenye rehema , 
Mkimbilie atakupokeya , 
Ni yeye tu anayeweza kuponya majeraha yako

Yeye kamwe hashindwi 
Tuna ushuhuda mwingi , 
Our Father is the King .
Never Be , Never Be Afraid

Alifungua njia kati ya bahari 
Na mapito kati ya maji yenye nguvu nyingi
Msiyakumbuke  mambo ya zamani.
Aliitenda jambo jipyaaa Tazama

Leo na Kesho anakujaza furaha 
Anaweka Maneno katika vitendo Jarah 
Chochote wanachopanga 
it doesn’t really Matter USISITE
Mwaminiye kwanza Baraka zitafuuata USISITE
Ana kujua , Anakukumbuka 
 USISITE
Anakutunza  ,Anakufahamu
USISITE

Mipango yake kwako ni njema hawezi kukuacha Yatima
he is always there for you USISISITE X 4

Aliitenda jambo jipyaaa Tazama

Leo na Kesho anakujaza furaha 
Anaweka Maneno katika vitendo Jarah 
Chochote wanachopanga 
it doesn’t really Matter USISITE
Mwaminiye kwanza Baraka zitafuuata USISITE
Ana kujua , Anakukumbuka 
 USISITE
Anakutunza  ,Anakufahamu
USISITE

MIE Music "Jesus is our Shepherd'

## Movie Details

- **Release Year**: 2025
- **Duration**: 9:16 minutes
- **Language**: Swahili
- **Category**: music
- **Content Rating**: G
- **Quality**: 4K

## Cast & Crew

- **Director**: Chriss Eazy
- **Producer**: Popieeh
- **Main Cast**: Vestine, Dorcas

## Watch Now

[Click here to watch "USiSiTE - Vestine & Dorcas ( Official Video 2025)"](https://www.youtube.com/embed/40-sh4v4K8M)

---

*Uploaded on 12/12/2025*
