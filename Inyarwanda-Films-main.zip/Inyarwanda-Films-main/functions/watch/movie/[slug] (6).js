// functions/watch/movie/[slug].js
export async function onRequest(context) {
  const { request, params, env } = context;
  const { slug } = params;

  try {
    // Use environment variables for security
    const GITHUB_TOKEN = env.GITHUB_TOKEN;
    const GITHUB_REPO = env.GITHUB_REPO || "Inyarwanda-Films";
    
    // Look for the video in the translated content directory
    const searchPaths = [
      `content/translated/${slug}.md`,
      `content/movies/translated/${slug}.md`,
      `content/translated/[${slug}][MOVIE][*].md`,
      `content/translated/[${slug}][TV-SERIES][*].md`
    ];
    
    let videoData = null;
    let filePath = '';
    
    // Try different paths to find the video
    for (const path of searchPaths) {
      const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_REPO}/contents/${path}`;
      
      try {
        const response = await fetch(GITHUB_API_URL, {
          headers: {
            'Authorization': `token ${GITHUB_TOKEN}`,
            'User-Agent': 'Rwanda-Cinema',
            'Accept': 'application/vnd.github.v3+json'
          }
        });
        
        if (response.ok) {
          const githubData = await response.json();
          const markdownContent = atob(githubData.content);
          videoData = parseVideoMarkdown(markdownContent, slug, 'MOVIE');
          filePath = path;
          break;
        }
      } catch (error) {
        console.log(`Failed to load from path: ${path}`);
      }
    }
    
    if (!videoData) {
      return new Response('Video not found', { 
        status: 404,
        headers: { 
          'Content-Type': 'text/html; charset=UTF-8',
          'Cache-Control': 'public, max-age=300'
        }
      });
    }

    // Get related videos (same translator or category)
    const relatedVideos = await getRelatedVideos(env, videoData);
    
    // Get latest videos for the category
    const latestVideos = await getLatestVideos(env, videoData, 10);
    
    const html = generateWatchPage(videoData, relatedVideos, latestVideos);
    
    return new Response(html, {
      headers: {
        'Content-Type': 'text/html; charset=UTF-8',
        'Cache-Control': 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch (error) {
    console.error('Error generating watch page:', error);
    return new Response('Error loading video content', { 
      status: 500,
      headers: { 
        'Content-Type': 'text/html; charset=UTF-8',
        'Cache-Control': 'public, max-age=300'
      }
    });
  }
}

async function getLatestVideos(env, currentVideo, limit = 10) {
  try {
    const GITHUB_TOKEN = env.GITHUB_TOKEN;
    const GITHUB_REPO = env.GITHUB_REPO || "Inyarwanda-Films";
    
    // Get all videos from the translated directory
    const translatedUrl = `https://api.github.com/repos/${GITHUB_REPO}/contents/content/translated`;
    
    const response = await fetch(translatedUrl, {
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'User-Agent': 'Rwanda-Cinema',
        'Accept': 'application/vnd.github.v3+json'
      }
    });

    if (!response.ok) return [];

    const files = await response.json();
    const allVideos = [];

    // Get all videos
    for (const file of files) {
      if (file.name.endsWith('.md') && file.type === 'file') {
        // Skip the current video
        if (file.name.includes(`[${currentVideo.title}]`) || 
            file.name.includes(currentVideo.slug)) {
          continue;
        }
        
        try {
          const fileResponse = await fetch(file.download_url);
          if (fileResponse.ok) {
            const content = await fileResponse.text();
            const videoData = parseVideoMarkdown(content, file.name, file.name);
            
            if (videoData && videoData.title) {
              // Add date for sorting
              videoData.sortDate = videoData.uploadDate ? new Date(videoData.uploadDate) : new Date();
              videoData.filename = file.name;
              allVideos.push(videoData);
            }
          }
        } catch (error) {
          console.warn(`Failed to parse ${file.name}:`, error);
        }
      }
    }
    
    // Sort by date (newest first)
    allVideos.sort((a, b) => b.sortDate - a.sortDate);
    
    // Get latest videos
    const latestVideos = allVideos.slice(0, Math.min(allVideos.length, limit * 2));
    
    // Randomly select from latest
    const randomVideos = [];
    const availableIndices = Array.from({length: latestVideos.length}, (_, i) => i);
    
    // Shuffle and pick
    for (let i = 0; i < Math.min(limit, availableIndices.length); i++) {
      const randomIndex = Math.floor(Math.random() * availableIndices.length);
      const videoIndex = availableIndices.splice(randomIndex, 1)[0];
      const video = latestVideos[videoIndex];
      
      // Clean up object for template
      const cleanVideo = {
        title: video.title,
        slug: video.slug,
        contentType: video.contentType,
        poster: video.poster,
        duration: video.duration,
        formattedDuration: video.formattedDuration,
        releaseYear: video.releaseYear,
        translator: video.translator,
        translatorSlug: video.translatorSlug,
        quality: video.quality,
        description: video.description,
        shortDate: video.shortDate || '',
        watchUrl: `/watch/${video.contentType === 'MOVIE' ? 'movie' : 'tv-series'}/${video.slug}`
      };
      
      randomVideos.push(cleanVideo);
    }
    
    return randomVideos;
  } catch (error) {
    console.error('Error fetching latest videos:', error);
    return [];
  }
}

async function getRelatedVideos(env, currentVideo) {
  try {
    const GITHUB_TOKEN = env.GITHUB_TOKEN;
    const GITHUB_REPO = env.GITHUB_REPO || "Inyarwanda-Films";
    
    const translatedUrl = `https://api.github.com/repos/${GITHUB_REPO}/contents/content/translated`;
    
    const response = await fetch(translatedUrl, {
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'User-Agent': 'Rwanda-Cinema',
        'Accept': 'application/vnd.github.v3+json'
      }
    });

    if (!response.ok) return [];

    const files = await response.json();
    const videos = [];

    // Get videos by same translator
    for (const file of files) {
      if (file.name.endsWith('.md') && file.type === 'file') {
        // Skip the current video
        if (file.name.includes(`[${currentVideo.title}]`) || 
            file.name.includes(currentVideo.slug)) {
          continue;
        }
        
        // Check if it's by the same translator
        const translatorMatch = file.name.match(/\[([^\]]+)\]\.md$/);
        if (translatorMatch && translatorMatch[1] === currentVideo.translator) {
          try {
            const fileResponse = await fetch(file.download_url);
            if (fileResponse.ok) {
              const content = await fileResponse.text();
              const videoData = parseVideoMarkdown(content, file.name, file.name);
              
              if (videoData && videoData.title) {
                videos.push({
                  title: videoData.title,
                  slug: videoData.slug,
                  contentType: videoData.contentType,
                  poster: videoData.poster,
                  duration: videoData.duration,
                  formattedDuration: videoData.formattedDuration,
                  releaseYear: videoData.releaseYear,
                  translator: videoData.translator,
                  quality: videoData.quality,
                  description: videoData.description,
                  shortDate: videoData.shortDate || '',
                  watchUrl: `/watch/${videoData.contentType === 'MOVIE' ? 'movie' : 'tv-series'}/${videoData.slug}`
                });
              }
            }
          } catch (error) {
            console.warn(`Failed to parse ${file.name}:`, error);
          }
        }
        
        // Only get 2-3 related videos
        if (videos.length >= 3) break;
      }
    }
    
    return videos;
  } catch (error) {
    console.error('Error fetching related videos:', error);
    return [];
  }
}

function parseVideoMarkdown(content, filename, slug) {
  try {
    // Parse YAML frontmatter
    const frontmatterMatch = content.match(/^---\n([\s\S]*?)\n---/);
    if (!frontmatterMatch) return null;
    
    const frontmatter = frontmatterMatch[1];
    const data = {};
    
    // Parse frontmatter lines
    const lines = frontmatter.split('\n');
    for (const line of lines) {
      if (!line.trim()) continue;
      
      const match = line.match(/^(\w+):\s*(.*)$/);
      if (match) {
        let [, key, value] = match;
        value = value.replace(/^["'](.*)["']$/, '$1').trim();
        
        // Handle array values
        if (value === '' && lines.includes(line)) {
          const nextLineIndex = lines.indexOf(line) + 1;
          if (nextLineIndex < lines.length && lines[nextLineIndex].trim().startsWith('-')) {
            value = [];
            for (let i = nextLineIndex; i < lines.length; i++) {
              const arrayLine = lines[i].trim();
              if (arrayLine.startsWith('-')) {
                const arrayValue = arrayLine.substring(1).trim().replace(/^["'](.*)["']$/, '$1');
                value.push(arrayValue);
              } else {
                break;
              }
            }
          }
        }
        // Handle array values in square brackets
        else if (value.startsWith('[') && value.endsWith(']')) {
          try {
            value = JSON.parse(value);
          } catch (e) {
            value = value.substring(1, value.length - 1)
              .split(',')
              .map(v => v.trim().replace(/^["'](.*)["']$/, '$1'))
              .filter(v => v);
          }
        }
        // Handle numbers
        else if (key === 'releaseYear' || key === 'views' || key === 'likes') {
          value = parseInt(value) || 0;
        }
        
        data[key] = value;
      }
    }
    
    // Extract from filename if not in frontmatter
    const filenameMatch = filename.match(/^\[([^\]]+)\]\[([^\]]+)\]\[([^\]]+)\]\.md$/);
    if (filenameMatch) {
      const [, title, contentType, translator] = filenameMatch;
      if (!data.title) data.title = title.replace(/-/g, ' ').trim();
      if (!data.contentType) data.contentType = contentType.trim();
      if (!data.translator) data.translator = translator.trim();
    }
    
    // Ensure required fields
    if (!data.slug) data.slug = slug.replace(/\.md$/, '').replace(/\[|\]/g, '');
    if (!data.contentType) data.contentType = 'MOVIE';
    
    // Format duration
    if (data.duration && data.duration !== 'Not specified') {
      data.formattedDuration = formatDurationForDisplay(data.duration);
      data.isoDuration = convertDurationToISO(data.duration);
    }
    
    // Format upload date
    if (data.uploadDate || data.dateAdded) {
      const date = new Date(data.uploadDate || data.dateAdded);
      data.shortDate = formatShortDate(date);
      data.formattedDate = formatDate(date);
    }
    
    // Generate translator slug
    if (data.translator) {
      data.translatorSlug = generateSlug(data.translator);
    }
    
    // Ensure quality
    if (!data.quality) data.quality = data.videoQuality || 'HD';
    
    return data;
    
  } catch (error) {
    console.warn(`Error parsing markdown:`, error);
    return null;
  }
}

function generateSlug(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function convertDurationToISO(duration) {
  if (!duration || duration === 'Not specified') return 'PT0M';
  
  // Handle "1:30:00" format
  const hmsMatch = duration.match(/^(\d+):(\d+):(\d+)$/);
  if (hmsMatch) {
    const [, hours, minutes, seconds] = hmsMatch;
    return `PT${hours}H${minutes}M${seconds}S`;
  }
  
  // Handle "30:00" format
  const msMatch = duration.match(/^(\d+):(\d+)$/);
  if (msMatch) {
    const [, minutes, seconds] = msMatch;
    return `PT${minutes}M${seconds}S`;
  }
  
  // Handle "90 minutes" format
  const minutesMatch = duration.match(/(\d+)\s*(?:min|minutes?)/i);
  if (minutesMatch) {
    const minutes = parseInt(minutesMatch[1]);
    return `PT${minutes}M`;
  }
  
  // Handle "2 hours" format
  const hoursMatch = duration.match(/(\d+)\s*(?:hr|hours?)/i);
  if (hoursMatch) {
    const hours = parseInt(hoursMatch[1]);
    return `PT${hours}H`;
  }
  
  // Handle "1h30m" format
  const hmMatch = duration.match(/(\d+)h\s*(\d+)m/i);
  if (hmMatch) {
    const [, hours, minutes] = hmMatch;
    return `PT${hours}H${minutes}M`;
  }
  
  return 'PT0M';
}

function formatDate(date) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('en-US', options);
}

function formatShortDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)}w ago`;
  if (diffDays < 365) return `${Math.floor(diffDays / 30)}mo ago`;
  return `${Math.floor(diffDays / 365)}y ago`;
}

function formatDurationForDisplay(duration) {
  if (!duration || duration === 'Not specified') return '';
  
  // Handle "1:30:00" format
  const hmsMatch = duration.match(/^(\d+):(\d+):(\d+)$/);
  if (hmsMatch) {
    const [, hours, minutes, seconds] = hmsMatch;
    return `${hours}h ${minutes}m`;
  }
  
  // Handle "30:00" format
  const msMatch = duration.match(/^(\d+):(\d+)$/);
  if (msMatch) {
    const [, minutes, seconds] = msMatch;
    return `${minutes}m`;
  }
  
  // Handle "90 minutes" format
  const minutesMatch = duration.match(/(\d+)\s*(?:min|minutes?)/i);
  if (minutesMatch) {
    const minutes = parseInt(minutesMatch[1]);
    return `${minutes}m`;
  }
  
  // Handle "2 hours" format
  const hoursMatch = duration.match(/(\d+)\s*(?:hr|hours?)/i);
  if (hoursMatch) {
    const hours = parseInt(hoursMatch[1]);
    return `${hours}h`;
  }
  
  // Handle "1h30m" format
  const hmMatch = duration.match(/(\d+)h\s*(\d+)m/i);
  if (hmMatch) {
    const [, hours, minutes] = hmMatch;
    return `${hours}h ${minutes}m`;
  }
  
  return duration;
}

function generateWatchPage(videoData, relatedVideos, latestVideos) {
  const pageUrl = `https://rwandacinema.site/watch/${videoData.contentType === 'MOVIE' ? 'movie' : 'tv-series'}/${videoData.slug}`;
  const isOdysee = videoData.videoUrl && videoData.videoUrl.includes('odysee.com');
  const embedUrl = isOdysee ? videoData.videoUrl.replace('https://odysee.com/', 'https://odysee.com/$/embed/') + '?r=1s8cJkToaSCoKtT2RyVTfP6V8ocp6cND' : videoData.videoUrl;
  
  // Format upload date for Schema.org
  const uploadDate = videoData.uploadDate ? new Date(videoData.uploadDate).toISOString() : new Date().toISOString();
  
  // Truncate description
  const fullDescription = videoData.description || videoData.shortDescription || '';
  const truncatedDescription = fullDescription.length > 250 ? 
    fullDescription.substring(0, 250) + '...' : 
    fullDescription;
  const showReadMore = fullDescription.length > 250;
  
  // Generate video cards HTML
  const generateVideoCards = (videos, sectionTitle, sectionId) => {
    if (videos.length === 0) return '';
    
    const cards = videos.map(video => {
      const title = escapeHTML(video.title);
      const posterUrl = video.poster || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg';
      const releaseYear = video.releaseYear || '';
      const duration = video.formattedDuration || '';
      const quality = video.quality || 'HD';
      const translator = video.translator || '';
      const shortDate = video.shortDate || '';
      
      return `<a href="${video.watchUrl}" class="related-card">
                <div class="related-thumbnail">
                  <img src="${posterUrl}" 
                       alt="${title}" 
                       onerror="this.src='https://inyarwanda-films.pages.dev/images/default-poster.jpg'">
                  
                  <!-- Quality badge -->
                  ${quality ? `
                  <div class="quality-badge">
                    ${quality}
                  </div>
                  ` : ''}
                  
                  <!-- Date badge -->
                  ${shortDate ? `
                  <div class="date-badge">
                    ${shortDate}
                  </div>
                  ` : ''}
                  
                  <!-- Duration badge -->
                  ${duration ? `
                  <div class="duration-badge">
                    ${duration}
                  </div>
                  ` : ''}
                  
                  <div class="related-overlay">
                    <div class="related-play">▶</div>
                  </div>
                </div>
                <div class="related-info">
                  <h3 class="related-title">${title}</h3>
                  <div class="related-meta">
                    ${releaseYear ? `<span>${releaseYear}</span>` : ''}
                    ${duration ? `<span>${duration}</span>` : ''}
                    ${translator ? `<span class="translator">${translator}</span>` : ''}
                  </div>
                </div>
              </a>`;
    }).join('');
    
    return `<section class="related-section" id="${sectionId}">
              <div class="section-header">
                <h2 class="section-title">${sectionTitle}</h2>
                <a href="/agasobanuye/" class="view-all">Browse All</a>
              </div>
              <div class="related-grid">
                ${cards}
              </div>
            </section>`;
  };
  
  const html = `<!DOCTYPE html>
<html lang="rw">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Primary Meta Tags -->
    <title>${escapeHTML(videoData.title)} | Watch Online - Rwanda Cinema</title>
    <meta name="description" content="${escapeHTML(videoData.metaDescription || videoData.description || videoData.shortDescription || 'Watch this Kinyarwanda film online')}">
    <meta name="keywords" content="${generateKeywords(videoData)}">
    <meta name="author" content="Rwanda Cinema">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="video.episode">
    <meta property="og:url" content="${pageUrl}">
    <meta property="og:title" content="${escapeHTML(videoData.title)} | Watch Online - Rwanda Cinema">
    <meta property="og:description" content="${escapeHTML(videoData.metaDescription || videoData.description || videoData.shortDescription || 'Watch this Kinyarwanda film online')}">
    <meta property="og:image" content="${videoData.poster || videoData.thumbnailUrl || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg'}">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:site_name" content="Rwanda Cinema">
    <meta property="video:duration" content="${videoData.isoDuration ? videoData.isoDuration.replace('PT', '').replace('M', '') : '1680'}">
    <meta property="video:release_date" content="${uploadDate}">
    <meta property="video:series" content="Rwanda Cinema">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="player">
    <meta property="twitter:url" content="${pageUrl}">
    <meta property="twitter:title" content="${escapeHTML(videoData.title)} | Watch Online - Rwanda Cinema">
    <meta property="twitter:description" content="${escapeHTML(videoData.metaDescription || videoData.description || videoData.shortDescription || 'Watch this Kinyarwanda film online')}">
    <meta property="twitter:image" content="${videoData.poster || videoData.thumbnailUrl || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg'}">
    <meta property="twitter:player" content="${pageUrl}">
    <meta property="twitter:player:width" content="1280">
    <meta property="twitter:player:height" content="720">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="${pageUrl}">
    
    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "${videoData.contentType === 'MOVIE' ? 'Movie' : 'TVSeries'}",
        "name": "${escapeHTML(videoData.title)}",
        "description": "${escapeHTML(videoData.metaDescription || videoData.description || videoData.shortDescription || 'Watch this Kinyarwanda film online')}",
        "image": "${videoData.poster || videoData.thumbnailUrl || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg'}",
        "thumbnailUrl": "${videoData.poster || videoData.thumbnailUrl || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg'}",
        "uploadDate": "${uploadDate}",
        "datePublished": "${uploadDate}",
        "duration": "${videoData.isoDuration || 'PT0M'}",
        "contentUrl": "${videoData.videoUrl}",
        "embedUrl": "${pageUrl}",
        "genre": "${videoData.genre ? (Array.isArray(videoData.genre) ? videoData.genre.join(', ') : videoData.genre) : 'Translated Content'}",
        "inLanguage": "rw",
        "subtitleLanguage": "en",
        "contentRating": "${videoData.rating || videoData.ageRestriction || 'G'}",
        "translator": {
            "@type": "Person",
            "name": "${videoData.translator || 'Unknown'}"
        },
        "author": {
            "@type": "Organization",
            "name": "Rwanda Cinema"
        },
        "publisher": {
            "@type": "Organization",
            "name": "Rwanda Cinema",
            "logo": {
                "@type": "ImageObject",
                "url": "https://rwandacinema.site/logo.png"
            }
        }
    }
    </script>
    
    <style>
        :root {
            --primary: #008753;
            --secondary: #FAD201;
            --accent: #00A1DE;
            --dark: #0a0a0a;
            --card-bg: #1a1a1a;
            --text-light: #e0e0e0;
            --border: #333;
        }
        
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body { 
            background: var(--dark); 
            color: white; 
            line-height: 1.6;
            min-height: 100vh;
            padding-bottom: 80px; /* Space for floating button */
        }
        
        .container { 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 0 1rem; 
        }
        
        .header { 
            background: var(--primary); 
            padding: 1rem 0; 
            border-bottom: 3px solid var(--secondary);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 2rem;
        }
        
        .logo {
            color: white;
            text-decoration: none;
            font-size: 1.5rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            white-space: nowrap;
        }
        
        .search-container {
            flex: 1;
            max-width: 500px;
            position: relative;
        }
        
        .search-form {
            display: flex;
            width: 100%;
        }
        
        .search-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 8px 0 0 8px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
        }
        
        .search-input:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 0 3px rgba(250, 210, 1, 0.3);
        }
        
        .search-input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .search-button {
            background: var(--secondary);
            color: var(--dark);
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0 8px 8px 0;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .search-button:hover {
            background: #e0c001;
        }
        
        .search-results {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--card-bg);
            border-radius: 8px;
            margin-top: 0.5rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            max-height: 400px;
            overflow-y: auto;
            display: none;
            z-index: 1001;
        }
        
        .search-results.active {
            display: block;
        }
        
        .search-result-item {
            padding: 1rem;
            border-bottom: 1px solid var(--border);
            display: block;
            text-decoration: none;
            color: white;
            transition: background 0.3s ease;
        }
        
        .search-result-item:hover {
            background: rgba(0, 135, 83, 0.2);
        }
        
        .search-result-title {
            font-weight: bold;
            margin-bottom: 0.25rem;
            color: var(--secondary);
        }
        
        .search-result-category {
            font-size: 0.9rem;
            color: var(--text-light);
        }
        
        .no-results {
            padding: 1rem;
            text-align: center;
            color: var(--text-light);
        }
        
        .search-loading {
            padding: 1rem;
            text-align: center;
            color: var(--secondary);
        }
        
        .breadcrumb {
            background: var(--card-bg);
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            font-size: 0.9rem;
        }
        
        .breadcrumb a {
            color: var(--secondary);
            text-decoration: none;
        }
        
        .breadcrumb span {
            color: var(--text-light);
            margin: 0 0.5rem;
        }
        
        .video-wrapper {
            background: #000;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            margin-bottom: 2rem;
        }
        
        .video-container {
            position: relative;
            width: 100%;
            height: 0;
            padding-bottom: 56.25%;
            background: #000;
        }
        
        .video-thumbnail {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: opacity 0.3s ease;
        }
        
        .video-thumbnail.hidden {
            opacity: 0;
            pointer-events: none;
        }
        
        .play-button {
            width: 80px;
            height: 80px;
            background: rgba(0, 135, 83, 0.9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            border: 4px solid white;
            box-shadow: 0 8px 32px rgba(0,0,0,0.5);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .play-button:hover {
            background: #006641;
            transform: scale(1.1);
        }
        
        .video-iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }
        
        /* Hide Odysee branding */
        .video-iframe.odysee {
            position: absolute !important;
            top: -60px !important;
            height: calc(100% + 120px) !important;
        }
        
        /* Floating Next Button */
        .floating-next-btn {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(135deg, var(--primary), #006641);
            color: white;
            border: none;
            padding: 18px 20px;
            font-weight: bold;
            cursor: pointer;
            z-index: 1000;
            opacity: 0;
            transform: translateY(100%);
            transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            font-size: 16px;
            text-decoration: none;
            text-align: center;
        }
        
        .floating-next-btn.visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        .floating-next-btn:hover {
            background: linear-gradient(135deg, #006641, #005233);
        }
        
        .floating-next-btn:active {
            transform: translateY(1px);
        }
        
        .next-btn-icon {
            font-size: 20px;
        }
        
        .next-btn-text {
            font-size: 16px;
            font-weight: bold;
        }
        
        .video-info {
            padding: 2rem;
            background: var(--card-bg);
        }
        
        .video-title {
            font-size: 2.2rem;
            font-weight: bold;
            color: white;
            margin-bottom: 1rem;
            line-height: 1.3;
        }
        
        .video-stats {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        .stat {
            color: var(--text-light);
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255,255,255,0.1);
            padding: 0.5rem 1rem;
            border-radius: 8px;
        }
        
        .video-description {
            color: var(--text-light);
            line-height: 1.7;
            font-size: 1.1rem;
            position: relative;
        }
        
        .video-description.truncated {
            max-height: 120px;
            overflow: hidden;
        }
        
        .video-description.full {
            max-height: none;
        }
        
        .read-more-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 0.5rem;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .read-more-btn:hover {
            background: #006641;
        }
        
        .movie-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .details-card {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid var(--border);
        }
        
        .details-card h2 {
            color: var(--secondary);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
        }
        
        .meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .meta-item {
            margin-bottom: 1rem;
        }
        
        .meta-item strong {
            color: var(--secondary);
            display: block;
            margin-bottom: 0.25rem;
            font-size: 0.9rem;
        }
        
        .meta-item p {
            color: white;
            margin: 0;
            font-size: 1rem;
        }
        
        .cast-crew {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }
        
        .cast-item {
            background: #252525;
            padding: 1rem;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }
        
        .cast-item strong {
            color: var(--secondary);
            display: block;
            margin-bottom: 0.5rem;
        }
        
        .cast-item p {
            color: white;
            margin: 0;
        }

        /* Related Videos Section */
        .related-section {
            margin: 4rem 0;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .section-title {
            font-size: 1.8rem;
            color: var(--secondary);
            border-bottom: 3px solid var(--primary);
            padding-bottom: 0.5rem;
        }

        .view-all {
            color: var(--accent);
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .view-all:hover {
            color: var(--secondary);
        }

        .related-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .related-card {
            background: var(--card-bg);
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .related-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.4);
            border-color: var(--primary);
        }

        .related-thumbnail {
            position: relative;
            width: 100%;
            height: 160px;
            overflow: hidden;
        }

        .related-thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .related-card:hover .related-thumbnail img {
            transform: scale(1.05);
        }

        /* Corner badges for related videos */
        .quality-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
            color: white;
            font-size: 0.7rem;
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 4px;
            z-index: 2;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }

        .date-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            color: var(--text-light);
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 4px;
            z-index: 2;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }

        .duration-badge {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            color: white;
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 4px;
            z-index: 2;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }

        .related-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .related-card:hover .related-overlay {
            opacity: 1;
        }

        .related-play {
            width: 40px;
            height: 40px;
            background: rgba(0, 135, 83, 0.9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
            border: 2px solid white;
        }

        .related-info {
            padding: 1.2rem;
        }

        .related-title {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
            line-height: 1.3;
            color: white;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .related-meta {
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .related-meta span {
            background: rgba(255,255,255,0.1);
            padding: 0.2rem 0.6rem;
            border-radius: 4px;
            font-size: 0.8rem;
            color: var(--text-light);
        }
        
        .related-meta .translator {
            background: rgba(0, 135, 83, 0.2);
            color: var(--secondary);
        }
        
        .footer {
            background: var(--card-bg);
            padding: 3rem 0;
            margin-top: 4rem;
            border-top: 3px solid var(--primary);
            text-align: center;
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
            }
            
            .search-container {
                max-width: 100%;
            }
            
            .video-title {
                font-size: 1.8rem;
            }
            
            .video-stats {
                gap: 1rem;
            }
            
            .movie-details {
                grid-template-columns: 1fr;
            }
            
            .video-info {
                padding: 1.5rem;
            }

            .related-grid {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }

            .section-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
            
            .floating-next-btn {
                padding: 16px 20px;
                font-size: 15px;
            }
            
            .next-btn-text {
                font-size: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .video-title {
                font-size: 1.5rem;
            }
            
            .video-stats {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .play-button {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
            }

            .related-grid {
                grid-template-columns: 1fr;
            }
            
            .floating-next-btn {
                padding: 14px 16px;
                font-size: 14px;
            }
            
            .next-btn-text {
                font-size: 14px;
            }
            
            .next-btn-icon {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <!-- Header with Search -->
    <header class="header" role="banner">
        <div class="container">
            <div class="header-content">
                <a href="/" class="logo" aria-label="Rwanda Cinema Home">
                    🎬 Rwanda Cinema
                </a>
                
                <div class="search-container">
                    <form class="search-form" id="searchForm">
                        <input type="text" 
                               class="search-input" 
                               id="searchInput" 
                               placeholder="Search for videos..." 
                               autocomplete="off"
                               aria-label="Search movies">
                        <button type="submit" class="search-button" aria-label="Search">
                            🔍 Search
                        </button>
                    </form>
                    <div class="search-results" id="searchResults" role="listbox">
                        <!-- Search results will be populated here -->
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container" role="main">
        <!-- Breadcrumb -->
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="/">Home</a>
            <span>></span>
            <a href="/agasobanuye/">Agasobanuye</a>
            <span>></span>
            <a href="/agasobanuye/?type=${videoData.contentType}">${videoData.contentType === 'MOVIE' ? 'Movies' : 'TV Shows'}</a>
            <span>></span>
            <span>${escapeHTML(videoData.title)}</span>
        </nav>

        <!-- Video Section -->
        <section class="video-section">
            <div class="video-wrapper">
                <div class="video-container">
                    <div class="video-thumbnail" id="videoThumbnail" 
                         style="background-image: url('${videoData.poster || videoData.thumbnailUrl || 'https://inyarwanda-films.pages.dev/images/default-poster.jpg'}')">
                        <div class="play-button" id="playButton" aria-label="Play ${escapeHTML(videoData.title)}">
                            ▶
                        </div>
                    </div>
                    <iframe class="video-iframe ${isOdysee ? 'odysee' : ''}" 
                            id="videoFrame" 
                            style="display: none;"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                            allowfullscreen
                            title="Watch ${escapeHTML(videoData.title)}">
                    </iframe>
                </div>
                
                <!-- Video Info -->
                <div class="video-info">
                    <h1 class="video-title">${escapeHTML(videoData.title)}</h1>
                    
                    <div class="video-stats">
                        <span class="stat">📅 ${videoData.releaseYear || ''}</span>
                        ${videoData.formattedDuration ? `<span class="stat">⏱️ ${videoData.formattedDuration}</span>` : ''}
                        <span class="stat">🎬 ${videoData.contentType === 'MOVIE' ? 'Movie' : 'TV Series'}</span>
                        <span class="stat">📦 ${videoData.quality || 'HD'}</span>
                        <span class="stat">👤 ${videoData.translator || 'Unknown'}</span>
                    </div>
                    
                    <div class="video-description ${showReadMore ? 'truncated' : 'full'}" id="videoDescription">
                        ${escapeHTML(fullDescription)}
                    </div>
                    ${showReadMore ? '<button class="read-more-btn" id="readMoreBtn" onclick="toggleDescription()">Read More</button>' : ''}
                </div>
            </div>
            
            <!-- Movie Details -->
            <div class="movie-details">
                <div class="details-card">
                    <h2>Content Information</h2>
                    <div class="meta-grid">
                        <div class="meta-item">
                            <strong>Type</strong>
                            <p>${videoData.contentType === 'MOVIE' ? 'Movie' : 'TV Series'}</p>
                        </div>
                        ${videoData.releaseYear ? `
                        <div class="meta-item">
                            <strong>Release Year</strong>
                            <p>${videoData.releaseYear}</p>
                        </div>
                        ` : ''}
                        ${videoData.language ? `
                        <div class="meta-item">
                            <strong>Language</strong>
                            <p>${videoData.language}</p>
                        </div>
                        ` : ''}
                        <div class="meta-item">
                            <strong>Quality</strong>
                            <p>${videoData.quality || 'HD'}</p>
                        </div>
                        ${videoData.rating || videoData.ageRestriction ? `
                        <div class="meta-item">
                            <strong>Rating</strong>
                            <p>${videoData.rating || videoData.ageRestriction || 'G'}</p>
                        </div>
                        ` : ''}
                        <div class="meta-item">
                            <strong>Translator</strong>
                            <p>${videoData.translator || 'Unknown'}</p>
                        </div>
                        ${videoData.uploadDate ? `
                        <div class="meta-item">
                            <strong>Uploaded</strong>
                            <p>${videoData.formattedDate || ''}</p>
                        </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="details-card">
                    <h2>Cast & Crew</h2>
                    <div class="cast-crew">
                        ${videoData.director ? `<div class="cast-item">
                            <strong>Director</strong>
                            <p>${escapeHTML(videoData.director)}</p>
                        </div>` : ''}
                        ${videoData.producer ? `<div class="cast-item">
                            <strong>Producer</strong>
                            <p>${escapeHTML(videoData.producer)}</p>
                        </div>` : ''}
                        ${videoData.mainCast ? `<div class="cast-item" style="grid-column: 1 / -1;">
                            <strong>Main Cast</strong>
                            <p>${escapeHTML(Array.isArray(videoData.mainCast) ? videoData.mainCast.join(', ') : videoData.mainCast)}</p>
                        </div>` : ''}
                        ${!videoData.director && !videoData.producer && !videoData.mainCast ? `<div class="cast-item" style="grid-column: 1 / -1;">
                            <p>Cast information not available</p>
                        </div>` : ''}
                    </div>
                </div>
            </div>
        </section>

        <!-- Latest Videos Section -->
        ${generateVideoCards(latestVideos, `Latest ${videoData.contentType === 'MOVIE' ? 'Movies' : 'TV Shows'}`, 'latestVideos')}

        <!-- Related Videos Section -->
        ${generateVideoCards(relatedVideos, `More from ${videoData.translator || 'This Translator'}`, 'relatedVideos')}
    </main>

    <!-- Footer -->
    <footer class="footer" role="contentinfo">
        <div class="container">
            <p>&copy; ${new Date().getFullYear()} Rwanda Cinema. All rights reserved.</p>
        </div>
    </footer>

    <!-- Floating Next Button -->
    ${latestVideos.length > 0 ? `<a href="#latestVideos" class="floating-next-btn" id="floatingNextBtn">
        <span class="next-btn-icon">⏭️</span>
        <span class="next-btn-text">Watch More ${videoData.contentType === 'MOVIE' ? 'Movies' : 'TV Shows'}</span>
    </a>` : ''}

    <script>
        // Video player functionality
        const thumbnail = document.getElementById('videoThumbnail');
        const playButton = document.getElementById('playButton');
        const videoFrame = document.getElementById('videoFrame');
        const floatingNextBtn = document.getElementById('floatingNextBtn');
        const isOdysee = ${isOdysee};
        const embedUrl = '${embedUrl}';
        
        let inactivityTimer;
        let isVideoPlaying = false;
        let isMouseOverPlayer = false;

        const startVideo = () => {
            if (!embedUrl) {
                alert('Video URL not available');
                return;
            }
            
            videoFrame.src = embedUrl;
            videoFrame.style.display = 'block';
            thumbnail.classList.add('hidden');
            isVideoPlaying = true;
            
            // Start monitoring inactivity
            startInactivityTimer();
            
            // Focus on iframe for accessibility
            setTimeout(() => {
                videoFrame.focus();
            }, 100);
        };

        const startInactivityTimer = () => {
            clearTimeout(inactivityTimer);
            hideNextButton();
            
            inactivityTimer = setTimeout(() => {
                if (isVideoPlaying && !isMouseOverPlayer) {
                    showNextButton();
                }
            }, 3000); // 3 seconds inactivity
        };

        const showNextButton = () => {
            if (floatingNextBtn) {
                floatingNextBtn.classList.add('visible');
            }
        };

        const hideNextButton = () => {
            if (floatingNextBtn) {
                floatingNextBtn.classList.remove('visible');
            }
        };

        // Description toggle functionality
        function toggleDescription() {
            const description = document.getElementById('videoDescription');
            const readMoreBtn = document.getElementById('readMoreBtn');
            
            if (description.classList.contains('truncated')) {
                description.classList.remove('truncated');
                description.classList.add('full');
                readMoreBtn.textContent = 'Read Less';
            } else {
                description.classList.remove('full');
                description.classList.add('truncated');
                readMoreBtn.textContent = 'Read More';
            }
        }

        // Search functionality
        const searchForm = document.getElementById('searchForm');
        const searchInput = document.getElementById('searchInput');
        const searchResults = document.getElementById('searchResults');
        const searchContainer = document.querySelector('.search-container');
        
        let searchTimeout;
        let searchAbortController = null;

        // Helper function for escaping text in JavaScript
        function escapeText(str) {
            if (!str) return '';
            return str.replace(/[&<>"']/g, 
                tag => ({
                    '&': '&amp;', '<': '&lt;', '>': '&gt;',
                    '"': '&quot;', "'": '&#39;'
                }[tag]));
        }

        // Helper function for capitalizing first letter in JavaScript
        function capitalizeFirst(str) {
            if (!str) return '';
            return str.charAt(0).toUpperCase() + str.slice(1);
        }

        // Event Listeners for video
        thumbnail.addEventListener('click', startVideo);
        playButton.addEventListener('click', (e) => {
            e.stopPropagation();
            startVideo();
        });

        // Mouse movement detection for entire page
        document.addEventListener('mousemove', () => {
            if (isVideoPlaying) {
                startInactivityTimer();
            }
        });

        // Video frame interactions
        if (videoFrame) {
            videoFrame.addEventListener('mouseenter', () => {
                isMouseOverPlayer = true;
                hideNextButton();
            });
            
            videoFrame.addEventListener('mouseleave', () => {
                isMouseOverPlayer = false;
                startInactivityTimer();
            });
            
            videoFrame.addEventListener('click', () => {
                hideNextButton();
                startInactivityTimer();
            });
            
            videoFrame.addEventListener('mousemove', () => {
                hideNextButton();
                startInactivityTimer();
            });
        }

        // Keyboard accessibility
        thumbnail.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                startVideo();
            }
        });

        // Smooth scroll for the floating button
        if (floatingNextBtn) {
            floatingNextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const latestSection = document.getElementById('latestVideos');
                if (latestSection) {
                    latestSection.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                    });
                    hideNextButton();
                }
            });
        }

        // Set thumbnail alt text for accessibility
        thumbnail.setAttribute('role', 'img');
        thumbnail.setAttribute('aria-label', 'Thumbnail for ${escapeHTML(videoData.title)}');

        // Simple search functionality
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (query.length >= 2) {
                window.location.href = \`/agasobanuye/?search=\${encodeURIComponent(query)}\`;
            }
        });

        // Focus search on Ctrl+K
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                searchInput.focus();
            }
        });
    </script>
</body>
</html>`;

  return html;
}

function escapeHTML(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, 
    tag => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;',
      '"': '&quot;', "'": '&#39;'
    }[tag]));
}

function generateKeywords(videoData) {
  const base = [
    'Rwandan movies', 'Kinyarwanda films', 'Inyarwanda Films', 
    'watch online', 'stream movies', videoData.contentType === 'MOVIE' ? 'movies' : 'TV shows',
    'Kinyarwanda translation', videoData.translator || '',
    videoData.title || ''
  ];
  
  if (videoData.genre && Array.isArray(videoData.genre)) {
    base.push(...videoData.genre);
  }
  
  if (videoData.metaKeywords && Array.isArray(videoData.metaKeywords)) {
    base.push(...videoData.metaKeywords);
  }
  
  return [...new Set(base)].filter(Boolean).join(', ');
            }
